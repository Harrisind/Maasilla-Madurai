
"use client"

import * as React from "react"
import {
  LayoutDashboard,
  ClipboardList,
  BrainCircuit,
  Settings,
  LogOut,
  Leaf,
  Zap,
  UserCircle,
  Check
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import Link from "next/link"
import { usePathname } from "next/navigation"

const navigation = [
  { 
    name: "M-Zero Hub", 
    href: "/dashboard", 
    icon: LayoutDashboard, 
    adminOnly: true,
    description: "City-wide command center for strategic metrics and monitoring."
  },
  { 
    name: "Ward League", 
    href: "/dashboard/wards", 
    icon: Zap,
    description: "Public rankings and personal impact rewards standings."
  },
  { 
    name: "Collection Logs", 
    href: "/collection-logs", 
    icon: ClipboardList, 
    adminOnly: true,
    description: "Real-time waste collection logs and evidence monitoring."
  },
  { 
    name: "AI Insights", 
    href: "/insights", 
    icon: BrainCircuit, 
    adminOnly: true,
    description: "AI-powered risk assessment and predictive analytics."
  },
]

export function AppSidebar() {
  const pathname = usePathname()
  const [role, setRole] = React.useState<string | null>(null)
  const [userName, setUserName] = React.useState("Officer")
  const [tempName, setTempName] = React.useState("")
  const [isProfileOpen, setIsProfileOpen] = React.useState(false)
  const [mounted, setMounted] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
    const storedRole = localStorage.getItem('userRole')
    const storedName = localStorage.getItem('userName')
    
    setRole(storedRole)
    if (storedName) {
      setUserName(storedName)
      setTempName(storedName)
    } else {
      const defaultName = storedRole === 'Admin' ? 'Commissioner' : 'Ward Officer'
      setUserName(defaultName)
      setTempName(defaultName)
    }
  }, [])

  const saveProfile = () => {
    localStorage.setItem('userName', tempName)
    setUserName(tempName)
    setIsProfileOpen(false)
    window.location.reload()
  }

  const filteredNavigation = React.useMemo(() => {
    if (!mounted) return []
    return navigation.filter(item => {
      if (item.adminOnly && role !== 'Admin') return false
      return true
    })
  }, [mounted, role])

  if (!mounted) {
    return (
      <Sidebar collapsible="icon">
        <SidebarHeader className="p-4">
          <div className="flex items-center gap-3">
            <div className="bg-primary p-2 rounded-xl text-primary-foreground shadow-lg">
              <Leaf className="size-5" />
            </div>
            <div className="flex flex-col group-data-[collapsible=icon]:hidden">
              <span className="font-bold text-lg text-primary leading-tight tracking-tight">M-Zero Madurai</span>
            </div>
          </div>
        </SidebarHeader>
        <SidebarContent />
        <SidebarFooter />
      </Sidebar>
    )
  }

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-3">
          <div className="bg-primary p-2 rounded-xl text-primary-foreground shadow-lg">
            <Leaf className="size-5" />
          </div>
          <div className="flex flex-col group-data-[collapsible=icon]:hidden">
            <span className="font-bold text-lg text-primary leading-tight tracking-tight">M-Zero Madurai</span>
            <span className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Civic FinTech</span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent className="px-2">
        <SidebarMenu className="mt-4">
          <TooltipProvider>
            {filteredNavigation.map((item) => (
              <SidebarMenuItem key={item.name}>
                <Tooltip delayDuration={300}>
                  <TooltipTrigger asChild>
                    <SidebarMenuButton 
                      asChild 
                      isActive={pathname === item.href}
                      className="rounded-xl font-bold h-10 px-4"
                    >
                      <Link href={item.href}>
                        <item.icon className="size-4" />
                        <span>{item.name}</span>
                      </Link>
                    </SidebarMenuButton>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="bg-primary text-white font-bold text-xs">
                    {item.description}
                  </TooltipContent>
                </Tooltip>
              </SidebarMenuItem>
            ))}
          </TooltipProvider>
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <SidebarSeparator className="mb-4" />
        <SidebarMenu>
          <SidebarMenuItem>
            <Dialog open={isProfileOpen} onOpenChange={setIsProfileOpen}>
              <DialogTrigger asChild>
                <SidebarMenuButton className="rounded-xl h-12 px-2 hover:bg-primary/5">
                  <Avatar className="size-8 rounded-lg">
                    <AvatarImage src={`https://picsum.photos/seed/${userName}/100/100`} />
                    <AvatarFallback className="bg-primary/10 text-primary font-bold">{userName[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col text-left group-data-[collapsible=icon]:hidden">
                    <span className="text-xs font-black truncate max-w-[120px]">{userName}</span>
                    <span className="text-[9px] text-muted-foreground font-bold uppercase">{role}</span>
                  </div>
                </SidebarMenuButton>
              </DialogTrigger>
              <DialogContent className="rounded-3xl sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-black">Edit Profile</DialogTitle>
                  <DialogDescription className="font-medium">Update your display name across the M-Zero network.</DialogDescription>
                </DialogHeader>
                <div className="py-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="font-bold">Your Full Name</Label>
                    <Input 
                      id="name" 
                      value={tempName} 
                      onChange={(e) => setTempName(e.target.value)} 
                      className="rounded-xl h-11"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button className="w-full rounded-xl font-bold h-11" onClick={saveProfile}>
                    <Check className="size-4 mr-2" /> Save Profile
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <TooltipProvider>
              <Tooltip delayDuration={300}>
                <TooltipTrigger asChild>
                  <SidebarMenuButton className="rounded-xl h-10 px-4">
                    <Settings className="size-4" />
                    <span>System Settings</span>
                  </SidebarMenuButton>
                </TooltipTrigger>
                <TooltipContent side="right" className="bg-muted text-muted-foreground font-bold text-xs">
                  Configure notification preferences and security keys.
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild className="text-destructive hover:text-destructive hover:bg-destructive/10 rounded-xl h-10 px-4">
              <Link href="/login" onClick={() => {
                localStorage.removeItem('userRole')
                localStorage.removeItem('userName')
              }}>
                <LogOut className="size-4" />
                <span>Logout Session</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  )
}
