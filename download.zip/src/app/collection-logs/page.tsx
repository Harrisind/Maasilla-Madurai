"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table"
import { ClipboardList, Image as ImageIcon, CheckCircle, XCircle, MapPin, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const logs = [
  { id: "LOG-001", hhId: "HH001", area: "Ward 10", status: "accepted", time: "08:15 AM", worker: "Murali", photo: "https://picsum.photos/seed/log1/400/300" },
  { id: "LOG-002", hhId: "HH012", area: "Ward 10", status: "rejected", time: "08:22 AM", worker: "Murali", reason: "Mixed plastic in wet waste", photo: "https://picsum.photos/seed/log2/400/300" },
  { id: "LOG-003", hhId: "HH005", area: "Ward 11", status: "accepted", time: "08:45 AM", worker: "Ganesh", photo: "https://picsum.photos/seed/log3/400/300" },
  { id: "LOG-004", hhId: "HH021", area: "Ward 12", status: "accepted", time: "09:02 AM", worker: "Ganesh", photo: "https://picsum.photos/seed/log4/400/300" },
  { id: "LOG-005", hhId: "HH099", area: "Ward 14", status: "rejected", time: "09:12 AM", worker: "Selvam", reason: "Hazardous waste mixed", photo: "https://picsum.photos/seed/log5/400/300" },
  { id: "LOG-006", hhId: "HH102", area: "Ward 13", status: "accepted", time: "09:25 AM", worker: "Selvam", photo: "https://picsum.photos/seed/log6/400/300" },
  { id: "LOG-007", hhId: "HH044", area: "Ward 10", status: "accepted", time: "09:30 AM", worker: "Murali", photo: "https://picsum.photos/seed/log7/400/300" },
]

const wards = ["All Wards", "Ward 10", "Ward 11", "Ward 12", "Ward 13", "Ward 14"]

export default function CollectionLogsPage() {
  const [selectedWard, setSelectedWard] = useState("All Wards")

  const filteredLogs = useMemo(() => {
    if (selectedWard === "All Wards") return logs
    return logs.filter(log => log.area === selectedWard)
  }, [selectedWard])

  const stats = useMemo(() => {
    const total = filteredLogs.length
    const rejected = filteredLogs.filter(l => l.status === "rejected").length
    const rejectionRate = total > 0 ? ((rejected / total) * 100).toFixed(1) : "0"
    
    return {
      total,
      rejectionRate: `${rejectionRate}%`
    }
  }, [filteredLogs])

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div className="flex flex-col gap-2">
          <h2 className="text-3xl font-black tracking-tight text-primary">Collection Monitoring</h2>
          <p className="text-muted-foreground font-medium">Real-time waste collection logs and evidence.</p>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border shadow-sm">
            <Filter className="size-4 text-muted-foreground" />
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Area Filter:</span>
            <Select value={selectedWard} onValueChange={setSelectedWard}>
              <SelectTrigger className="w-[180px] border-none shadow-none focus:ring-0 h-8 font-bold text-primary">
                <SelectValue placeholder="Select Ward" />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                {wards.map(ward => (
                  <SelectItem key={ward} value={ward} className="font-medium">
                    {ward}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <Badge variant="outline" className="hidden md:flex px-4 py-1.5 text-sm bg-primary/5 text-primary border-primary/20 rounded-xl">
            <div className="size-2 bg-green-500 rounded-full mr-2 animate-pulse" />
            Live Feed
          </Badge>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="rounded-3xl border-none shadow-sm bg-white overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-bold uppercase text-muted-foreground tracking-widest">Wards Scanned</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-black">{selectedWard === "All Wards" ? "100" : "1"} / 100</div>
            <div className="text-[10px] text-muted-foreground mt-1 font-bold">ACTIVE COVERAGE</div>
          </CardContent>
        </Card>
        <Card className="rounded-3xl border-none shadow-sm bg-white overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-bold uppercase text-muted-foreground tracking-widest">Logs in View</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-black">{filteredLogs.length} Entries</div>
            <div className="text-[10px] text-muted-foreground mt-1 font-bold">LAST 2 HOURS</div>
          </CardContent>
        </Card>
        <Card className={`rounded-3xl border-none shadow-sm overflow-hidden ${parseFloat(stats.rejectionRate) > 20 ? 'bg-destructive/10' : 'bg-white'}`}>
          <CardHeader className="pb-2">
            <CardTitle className={`text-xs font-bold uppercase tracking-widest ${parseFloat(stats.rejectionRate) > 20 ? 'text-destructive' : 'text-muted-foreground'}`}>Rejection Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-black ${parseFloat(stats.rejectionRate) > 20 ? 'text-destructive' : 'text-foreground'}`}>{stats.rejectionRate}</div>
            <div className="text-[10px] text-muted-foreground mt-1 font-bold uppercase">Compliance Efficiency</div>
          </CardContent>
        </Card>
        <Card className="rounded-3xl border-none shadow-sm bg-primary text-primary-foreground overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-bold uppercase opacity-70 tracking-widest">Field Strength</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-black">124 Workers</div>
            <div className="text-[10px] opacity-70 mt-1 font-bold uppercase">On Ground Now</div>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-3xl border-none shadow-sm bg-white overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="font-black text-xl">Recent Activity Log</CardTitle>
            <CardDescription className="font-medium">{selectedWard === "All Wards" ? "Monitoring across all areas" : `Monitoring ${selectedWard}`}</CardDescription>
          </div>
          <Button variant="outline" size="sm" className="rounded-xl font-bold">Download CSV</Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="font-bold uppercase text-[10px]">Log ID</TableHead>
                <TableHead className="font-bold uppercase text-[10px]">Area</TableHead>
                <TableHead className="font-bold uppercase text-[10px]">Household</TableHead>
                <TableHead className="font-bold uppercase text-[10px]">Worker</TableHead>
                <TableHead className="font-bold uppercase text-[10px]">Time</TableHead>
                <TableHead className="font-bold uppercase text-[10px]">Status</TableHead>
                <TableHead className="font-bold uppercase text-[10px] text-right">Evidence</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.map((log) => (
                <TableRow key={log.id} className="group hover:bg-muted/30 transition-colors">
                  <TableCell className="font-mono text-[10px] font-bold text-muted-foreground">{log.id}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="rounded-lg text-[10px] font-black tracking-tight bg-muted/50">
                      <MapPin className="size-2 mr-1" /> {log.area}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-black text-sm">{log.hhId}</TableCell>
                  <TableCell className="font-medium text-sm text-muted-foreground">{log.worker}</TableCell>
                  <TableCell className="text-xs font-bold text-muted-foreground">{log.time}</TableCell>
                  <TableCell>
                    {log.status === "accepted" ? (
                      <div className="flex items-center text-primary">
                        <CheckCircle className="size-3.5 mr-1.5" />
                        <span className="text-xs font-black uppercase tracking-tighter">Accepted</span>
                      </div>
                    ) : (
                      <div className="flex items-center text-destructive">
                        <XCircle className="size-3.5 mr-1.5" />
                        <div className="flex flex-col">
                          <span className="text-xs font-black uppercase tracking-tighter">Rejected</span>
                          {log.reason && (
                            <span className="text-[9px] text-muted-foreground font-bold italic truncate max-w-[120px]">
                              {log.reason}
                            </span>
                          )}
                        </div>
                      </div>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-9 w-9 rounded-xl hover:bg-primary/10">
                          <ImageIcon className="size-4 text-muted-foreground group-hover:text-primary transition-colors" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-80 rounded-2xl p-4 shadow-2xl border-none">
                        <div className="space-y-3">
                          <h4 className="font-black text-sm flex items-center gap-2">
                            <ImageIcon className="size-4 text-primary" />
                            Evidence Photo
                          </h4>
                          <div className="relative aspect-video rounded-xl overflow-hidden bg-muted border shadow-inner">
                            <Image 
                              src={log.photo} 
                              alt="Waste evidence" 
                              fill 
                              className="object-cover"
                              data-ai-hint="waste segregation"
                            />
                          </div>
                          <div className="flex justify-between items-center text-[10px] text-muted-foreground font-bold uppercase tracking-widest bg-muted/30 p-2 rounded-lg">
                            <span className="flex items-center gap-1">
                              <MapPin className="size-2" /> 9.9252° N, 78.1198° E
                            </span>
                            <span>{log.time}</span>
                          </div>
                        </div>
                      </PopoverContent>
                    </Popover>
                  </TableCell>
                </TableRow>
              ))}
              {filteredLogs.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="h-32 text-center text-muted-foreground font-bold italic">
                    No logs found for the selected ward.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
