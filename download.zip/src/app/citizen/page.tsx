
"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { 
  Wallet, 
  Flame, 
  Star, 
  ShoppingBag, 
  ArrowRight, 
  ArrowUpRight,
  ShieldCheck,
  Send,
  Loader2,
  Zap,
  Clock,
  Truck,
  Bus,
  Sparkles
} from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import Image from "next/image"

export default function CitizenWalletPage() {
  const { toast } = useToast()
  const [withdrawing, setWithdrawing] = useState(false)
  const [upiId, setUpiId] = useState("murali@okaxis")
  const [amount, setAmount] = useState("500")
  const [open, setOpen] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [userName, setUserName] = useState("Citizen")

  useEffect(() => {
    setMounted(true)
    const savedName = localStorage.getItem('userName')
    if (savedName) setUserName(savedName)
  }, [])

  const handleWithdraw = () => {
    if (!upiId.includes("@")) {
      toast({
        variant: "destructive",
        title: "Invalid UPI ID",
        description: "Please enter a valid UPI ID (e.g., name@bank)."
      })
      return
    }

    setWithdrawing(true)
    setTimeout(() => {
      setWithdrawing(false)
      setOpen(false)
      toast({
        title: "Transfer Initiated",
        description: `₹${(parseInt(amount) / 4).toFixed(2)} is being sent to ${upiId}.`,
      })
    }, 2000)
  }

  if (!mounted) return null

  return (
    <div className="max-w-md mx-auto space-y-6 pb-24">
      <div className="flex flex-col gap-1 px-4 pt-4">
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <Badge variant="outline" className="w-fit mb-1 bg-primary/5 text-primary border-primary/20 font-bold flex items-center gap-1">
              <Sparkles className="size-2.5" /> Welcome, {userName}
            </Badge>
            <h2 className="text-2xl font-black text-primary">M-Zero Wallet</h2>
          </div>
          <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20 h-fit">
            <ShieldCheck className="size-3 mr-1" /> Verified
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">Cleaning Madurai, One Credit at a Time.</p>
      </div>

      {/* Live Tracker Card */}
      <Card className="mx-4 rounded-3xl border-none shadow-lg overflow-hidden bg-white ring-2 ring-primary/5">
        <CardHeader className="p-4 pb-2 border-b bg-muted/20">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="size-2 bg-green-500 rounded-full animate-pulse" />
              <CardTitle className="text-xs font-black uppercase tracking-widest text-primary">Live Collection Tracker</CardTitle>
            </div>
            <Badge variant="secondary" className="text-[9px] font-bold">WARD 10</Badge>
          </div>
        </CardHeader>
        <CardContent className="p-0 relative h-48 group">
          <Image 
            src="https://picsum.photos/seed/madurai-live-mobile/600/400" 
            alt="Live Track" 
            fill 
            className="object-cover opacity-80"
            data-ai-hint="city map"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
             <div className="size-4 bg-primary border-2 border-white rounded-full shadow-lg" />
          </div>

          <div className="absolute top-1/3 right-1/4 animate-bounce">
             <div className="bg-accent p-1.5 rounded-lg shadow-xl border border-white">
                <Truck className="size-4 text-accent-foreground" />
             </div>
          </div>

          <div className="absolute bottom-3 left-4 right-4 text-white flex justify-between items-end">
            <div>
              <p className="text-[10px] font-black uppercase opacity-80 tracking-widest">Next Stop: Your Block</p>
              <h4 className="text-lg font-black leading-tight">Murali is 450m away</h4>
            </div>
            <div className="bg-white/20 backdrop-blur-md px-3 py-1 rounded-xl flex items-center gap-2 border border-white/20">
               <Clock className="size-3 text-accent" />
               <span className="text-xs font-black">~6 mins</span>
            </div>
          </div>
        </CardContent>
        <div className="p-4 bg-primary/5 flex items-center justify-between">
           <div className="flex items-center gap-3">
              <div className="size-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-xs uppercase">RM</div>
              <div>
                 <p className="text-[10px] font-black uppercase text-muted-foreground">Sanitary Hero</p>
                 <p className="text-sm font-bold">R. Murali</p>
              </div>
           </div>
           <div className="flex items-center gap-1">
              <Star className="size-3 text-accent fill-accent" />
              <span className="text-xs font-black">4.9</span>
           </div>
        </div>
      </Card>

      <Card className="mx-4 bg-primary text-primary-foreground shadow-2xl border-none relative overflow-hidden rounded-3xl">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Wallet className="size-32" />
        </div>
        <CardHeader>
          <div className="flex items-center gap-2 mb-1">
            <CardDescription className="text-primary-foreground/80 font-medium">Clean Credits Balance</CardDescription>
            <Badge variant="outline" className="bg-white/10 text-white border-white/20 text-[8px] h-4">
              <ShieldCheck className="size-2 mr-1" /> UPI Linked
            </Badge>
          </div>
          <div className="flex items-end justify-between">
            <CardTitle className="text-4xl font-black tracking-tighter">4,250 🌿</CardTitle>
            
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button variant="secondary" size="sm" className="rounded-xl font-bold gap-2">
                  <ArrowUpRight className="size-4" /> Withdraw to UPI
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px] rounded-3xl">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-black text-primary">UPI Transfer</DialogTitle>
                  <DialogDescription>
                    Convert your Clean Credits to cash instantly.
                    <br />
                    <span className="font-bold text-foreground">Rate: 4 Credits = ₹1.00</span>
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-6 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="upi" className="font-bold">Linked UPI ID</Label>
                    <div className="relative">
                      <Input 
                        id="upi" 
                        placeholder="username@okaxis" 
                        className="rounded-xl h-12 pl-10"
                        value={upiId}
                        onChange={(e) => setUpiId(e.target.value)}
                      />
                      <ShieldCheck className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-primary" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="amount" className="font-bold">Credits to Redeem</Label>
                    <Input 
                      id="amount" 
                      type="number" 
                      placeholder="Min 200" 
                      className="rounded-xl h-12"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                    />
                    <p className="text-[10px] text-muted-foreground font-medium italic">
                      Payout: ₹{(parseInt(amount || "0") / 4).toFixed(2)}
                    </p>
                  </div>
                </div>
                <DialogFooter>
                  <Button 
                    className="w-full h-12 rounded-xl font-black text-lg gap-2" 
                    onClick={handleWithdraw}
                    disabled={withdrawing || !amount || !upiId}
                  >
                    {withdrawing ? (
                      <>
                        <Loader2 className="size-5 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Send className="size-5" />
                        Transfer Now
                      </>
                    )}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="flex flex-col">
              <span className="text-[10px] uppercase font-bold opacity-70">Tax Rebate Value</span>
              <span className="text-lg font-bold">₹1,245.00</span>
            </div>
            <div className="w-px bg-white/20" />
            <div className="flex flex-col">
              <span className="text-[10px] uppercase font-bold opacity-70">Current Streak</span>
              <span className="text-lg font-bold flex items-center">
                <Flame className="size-4 mr-1 text-accent fill-accent" /> 12 Days
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="px-4 space-y-4">
        <h3 className="font-black text-lg flex items-center text-primary">
          <ShoppingBag className="mr-2 size-5" />
          Redeem Rewards
        </h3>
        <div className="space-y-3">
          {[
            { title: "TNPST Transport Pass", cost: "800 Credits", icon: <Bus className="size-6 text-green-700" />, color: "bg-green-100" },
            { title: "Property Tax Rebate", cost: "3000 Credits", icon: <ArrowUpRight className="size-6 text-blue-700" />, color: "bg-blue-100" },
            { title: "Groceries @ Reliance", cost: "500 Credits", icon: <ShoppingBag className="size-6 text-orange-700" />, color: "bg-orange-100" },
          ].map((item, i) => (
            <Card key={i} className="rounded-2xl group cursor-pointer hover:shadow-md transition-all border-none bg-white shadow-sm overflow-hidden">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`size-12 rounded-2xl flex items-center justify-center ${item.color}`}>
                    {item.icon}
                  </div>
                  <div>
                    <h4 className="font-bold text-sm">{item.title}</h4>
                    <p className="text-xs text-muted-foreground font-bold">{item.cost}</p>
                  </div>
                </div>
                <ArrowRight className="size-4 text-muted-foreground group-hover:translate-x-1 transition-transform" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <TooltipProvider>
        <nav className="fixed bottom-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-md border-t flex items-center justify-around px-4 z-50">
          <Tooltip delayDuration={300}>
            <TooltipTrigger asChild>
              <Button asChild variant="ghost" className="flex flex-col items-center gap-1 h-auto text-primary">
                <Link href="/citizen">
                  <Wallet className="size-5" />
                  <span className="text-[10px] font-bold">Wallet</span>
                </Link>
              </Button>
            </TooltipTrigger>
            <TooltipContent className="bg-primary text-white font-bold text-xs mb-2">
              View your credits, streaks, and withdrawal options.
            </TooltipContent>
          </Tooltip>

          <Tooltip delayDuration={300}>
            <TooltipTrigger asChild>
              <Button asChild variant="ghost" className="flex flex-col items-center gap-1 h-auto text-muted-foreground">
                <Link href="/dashboard/wards?tab=wallet">
                  <Zap className="size-5" />
                  <span className="text-[10px] font-bold">League</span>
                </Link>
              </Button>
            </TooltipTrigger>
            <TooltipContent className="bg-primary text-white font-bold text-xs mb-2">
              Check ward rankings and community impact scores.
            </TooltipContent>
          </Tooltip>

          <Tooltip delayDuration={300}>
            <TooltipTrigger asChild>
              <Button variant="ghost" className="flex flex-col items-center gap-1 h-auto text-muted-foreground">
                <ShoppingBag className="size-5" />
                <span className="text-[10px] font-bold">Market</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent className="bg-primary text-white font-bold text-xs mb-2">
              Redeem credits for tax rebates, bus passes, and coupons.
            </TooltipContent>
          </Tooltip>

          <Tooltip delayDuration={300}>
            <TooltipTrigger asChild>
              <Button variant="ghost" className="flex flex-col items-center gap-1 h-auto text-muted-foreground">
                <Star className="size-5" />
                <span className="text-[10px] font-bold">Quests</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent className="bg-primary text-white font-bold text-xs mb-2">
              Complete special challenges to earn bonus credits.
            </TooltipContent>
          </Tooltip>
        </nav>
      </TooltipProvider>
    </div>
  )
}
