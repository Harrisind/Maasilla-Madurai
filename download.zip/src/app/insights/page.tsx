"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BrainCircuit, Loader2, AlertTriangle, Lightbulb, Sparkles, TrendingDown } from "lucide-react"
import { aiCollectionLogSummary, CollectionLogSummaryOutput } from "@/ai/flows/ai-collection-log-summary"
import { aiComplianceRiskAnalysis, AiComplianceRiskAnalysisOutput } from "@/ai/flows/ai-compliance-risk-analysis"
import { useToast } from "@/hooks/use-toast"

export default function InsightsPage() {
  const [loading, setLoading] = useState(false)
  const [summaryData, setSummaryData] = useState<CollectionLogSummaryOutput | null>(null)
  const [riskData, setRiskData] = useState<AiComplianceRiskAnalysisOutput | null>(null)
  const { toast } = useToast()

  const generateInsights = async () => {
    setLoading(true)
    try {
      // Mocked data for the flow inputs
      const summaryResult = await aiCollectionLogSummary({
        wardId: "W14",
        collectionLogs: [
          {
            logId: "L1",
            householdId: "HH01",
            status: "rejected",
            rejectionReason: "Mixed wet and dry waste",
            timestamp: new Date().toISOString(),
            wasteType: "mixed",
            notes: "House owner was informed but refused to segregate."
          },
          {
            logId: "L2",
            householdId: "HH02",
            status: "rejected",
            rejectionReason: "Plastic in wet bin",
            timestamp: new Date().toISOString(),
            wasteType: "wet",
            notes: "Repeat offender."
          }
        ]
      })

      const riskResult = await aiComplianceRiskAnalysis({
        entityId: "W14",
        entityType: "ward",
        complianceHistory: [
          { date: "2024-05-20", status: "non-compliant", reason: "Poor segregation at source" },
          { date: "2024-05-18", status: "partially-compliant", reason: "Improved after notice" }
        ],
        wasteDetails: {
          averageSegregationScore: 38,
          commonSegregationErrors: ["Plastic in wet waste", "Hazardous batteries in dry waste"]
        },
        rejectionReasons: ["Mixed waste", "Contaminated recyclables"]
      })

      setSummaryData(summaryResult)
      setRiskData(riskResult)
      
      toast({
        title: "AI Analysis Complete",
        description: "Latest insights and risk analysis generated successfully."
      })
    } catch (error) {
      console.error(error)
      toast({
        variant: "destructive",
        title: "Analysis Failed",
        description: "Could not connect to GenAI endpoints. Please try again."
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex flex-col gap-2">
          <h2 className="text-3xl font-bold tracking-tight text-primary flex items-center">
            <BrainCircuit className="mr-3 size-8 text-accent" />
            AI Compliance Insights
          </h2>
          <p className="text-muted-foreground">Generative AI-powered risk assessment and pattern identification.</p>
        </div>
        <Button onClick={generateInsights} disabled={loading} size="lg" className="shadow-lg">
          {loading ? (
            <Loader2 className="mr-2 size-4 animate-spin" />
          ) : (
            <Sparkles className="mr-2 size-4" />
          )}
          Generate Proactive Insights
        </Button>
      </div>

      {!summaryData && !riskData && !loading && (
        <Card className="border-dashed py-12">
          <CardContent className="flex flex-col items-center text-center">
            <div className="bg-primary/5 p-6 rounded-full mb-4">
              <BrainCircuit className="size-12 text-primary opacity-20" />
            </div>
            <h3 className="text-xl font-bold mb-2">Ready for Analysis</h3>
            <p className="text-muted-foreground max-w-md">
              Run the AI engine to analyze recent collection logs and household compliance history to predict future risks.
            </p>
          </CardContent>
        </Card>
      )}

      {loading && (
        <div className="grid gap-6">
          <div className="animate-pulse bg-muted h-[200px] rounded-xl" />
          <div className="animate-pulse bg-muted h-[400px] rounded-xl" />
        </div>
      )}

      {(summaryData || riskData) && !loading && (
        <div className="grid gap-6">
          <div className="grid md:grid-cols-3 gap-6">
            <Card className={`border-2 ${riskData?.riskLevel === 'critical' || riskData?.riskLevel === 'high' ? 'border-destructive/20' : 'border-primary/20'}`}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
                  Compliance Risk Level
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className={`text-3xl font-bold capitalize ${riskData?.riskLevel === 'critical' ? 'text-destructive' : 'text-primary'}`}>
                    {riskData?.riskLevel || "N/A"}
                  </div>
                  <div className="text-4xl font-black opacity-10">{riskData?.riskScore}%</div>
                </div>
                <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
                  <AlertTriangle className="size-4 text-accent" />
                  <span>Significant non-compliance patterns detected</span>
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
                  Executive AI Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm leading-relaxed text-foreground">
                  {summaryData?.summary || "No summary available."}
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-primary">
                  <Lightbulb className="mr-2 size-5 text-accent" />
                  Actionable Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {riskData?.recommendations.map((rec, i) => (
                    <li key={i} className="text-sm flex gap-3">
                      <div className="size-1.5 rounded-full bg-accent mt-1.5 shrink-0" />
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-primary">
                  <TrendingDown className="mr-2 size-5 text-destructive" />
                  Emerging Patterns
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm mb-4 leading-relaxed">
                  {summaryData?.emergingPatterns}
                </p>
                <div className="space-y-4">
                  <h4 className="text-xs font-bold uppercase text-muted-foreground">Predicted Future Compliance</h4>
                  <div className="p-4 bg-muted/40 rounded-lg text-sm italic">
                    "{riskData?.predictedFutureCompliance}"
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}