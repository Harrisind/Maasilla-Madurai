"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table"
import { Search, Filter, Home, History, AlertCircle } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger
} from "@/components/ui/dialog"

const householdData = [
  { id: "HH001", address: "12, Bharathi St, Ward 10", status: "Compliant", lastScore: 95, owner: "Rajesh Kumar", visits: 12 },
  { id: "HH002", address: "45, Kamarajar Rd, Ward 10", status: "Non-Compliant", lastScore: 42, owner: "Meena Swaminathan", visits: 10 },
  { id: "HH003", address: "2, Temple View, Ward 11", status: "Partial", lastScore: 68, owner: "Suresh Mani", visits: 15 },
  { id: "HH004", address: "89, South Gate, Ward 12", status: "Compliant", lastScore: 88, owner: "Anitha Devi", visits: 8 },
  { id: "HH005", address: "156, TVS Nagar, Ward 13", status: "Compliant", lastScore: 91, owner: "Vignesh Raja", visits: 22 },
]

export default function HouseholdsPage() {
  const [selectedHH, setSelectedHH] = useState<typeof householdData[0] | null>(null)

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div className="flex flex-col gap-2">
          <h2 className="text-3xl font-bold tracking-tight text-primary">Household Management</h2>
          <p className="text-muted-foreground">Detailed compliance tracking for individual households.</p>
        </div>
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search HH ID / Name..."
              className="pl-8 w-[250px]"
            />
          </div>
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Filters
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-primary/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Home className="mr-2 size-4 text-primary" />
              Total Registered
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">15,420</div>
          </CardContent>
        </Card>
        <Card className="bg-accent/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <AlertCircle className="mr-2 size-4 text-accent" />
              Need Attention
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,245</div>
          </CardContent>
        </Card>
        <Card className="bg-destructive/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center text-destructive">
              <History className="mr-2 size-4" />
              Repeat Offenders
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">482</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Household List</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>HH ID</TableHead>
                <TableHead>Address</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>Compliance Status</TableHead>
                <TableHead>Avg Score</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {householdData.map((hh) => (
                <TableRow key={hh.id}>
                  <TableCell className="font-mono text-xs">{hh.id}</TableCell>
                  <TableCell className="max-w-[200px] truncate">{hh.address}</TableCell>
                  <TableCell>{hh.owner}</TableCell>
                  <TableCell>
                    <Badge 
                      variant={
                        hh.status === "Compliant" ? "default" : 
                        hh.status === "Partial" ? "secondary" : "destructive"
                      }
                      className="rounded-full"
                    >
                      {hh.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span className={`font-bold ${hh.lastScore > 80 ? 'text-primary' : hh.lastScore > 60 ? 'text-accent' : 'text-destructive'}`}>
                      {hh.lastScore}%
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setSelectedHH(hh)}
                        >
                          Details
                        </Button>
                      </DialogTrigger>
                      {selectedHH && (
                        <DialogContent className="sm:max-w-[425px]">
                          <DialogHeader>
                            <DialogTitle>Household Profile: {selectedHH.id}</DialogTitle>
                            <DialogDescription>
                              Compliance history and detailed metrics.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="grid gap-4 py-4">
                            <div className="grid grid-cols-4 items-center gap-4">
                              <span className="text-sm font-bold">Owner:</span>
                              <span className="col-span-3 text-sm">{selectedHH.owner}</span>
                            </div>
                            <div className="grid grid-cols-4 items-center gap-4">
                              <span className="text-sm font-bold">Visits:</span>
                              <span className="col-span-3 text-sm">{selectedHH.visits} recordings</span>
                            </div>
                            <div className="border rounded-md p-4 bg-muted/20">
                              <h4 className="text-xs font-bold uppercase mb-2">Recent Logs</h4>
                              <div className="space-y-2">
                                <div className="flex justify-between text-xs border-b pb-1">
                                  <span>24 May, 2024</span>
                                  <Badge className="text-[10px] h-4">Accepted</Badge>
                                </div>
                                <div className="flex justify-between text-xs border-b pb-1">
                                  <span>23 May, 2024</span>
                                  <Badge className="text-[10px] h-4">Accepted</Badge>
                                </div>
                                <div className="flex justify-between text-xs">
                                  <span>22 May, 2024</span>
                                  <Badge variant="destructive" className="text-[10px] h-4">Rejected</Badge>
                                </div>
                              </div>
                            </div>
                          </div>
                        </DialogContent>
                      )}
                    </Dialog>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}