
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { 
  Leaf, 
  ArrowRight, 
  Home, 
  Truck, 
  Building2, 
  ShieldCheck,
  UserCircle2,
  Zap
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"

export default function LandingPage() {
  const portals = [
    {
      title: "Households",
      description: "Access your Green Wallet, track streaks, and claim property tax rebates.",
      icon: Home,
      href: "/login?role=citizen",
      color: "bg-blue-100 text-blue-700",
      label: "Access Green Wallet"
    },
    {
      title: "Sanitary Workers",
      description: "Thooimai Kaavalargal portal for route scanning and collection logging.",
      icon: Truck,
      href: "/login?role=worker",
      color: "bg-orange-100 text-orange-700",
      label: "Start Field Scan"
    },
    {
      title: "Ward Officers",
      description: "Monitor ward-level performance, compliance heatmaps, and local issues.",
      icon: Building2,
      href: "/login?role=ward-officer",
      color: "bg-green-100 text-green-700",
      label: "Manage Ward"
    },
    {
      title: "Commissioners",
      description: "City-wide command center for strategic metrics and Swachh forecasts.",
      icon: UserCircle2,
      href: "/login?role=commissioner",
      color: "bg-purple-100 text-purple-700",
      label: "Command Center"
    }
  ]

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="px-6 h-20 flex items-center justify-between border-b bg-white/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="bg-primary p-2 rounded-xl text-primary-foreground">
            <Leaf className="size-6" />
          </div>
          <span className="font-bold text-2xl tracking-tighter text-primary">Maasilla Madurai</span>
        </div>
        <div className="flex items-center gap-3">
          <Button asChild variant="ghost" className="rounded-full font-bold">
            <Link href="/dashboard/wards">Public League</Link>
          </Button>
          <Button asChild variant="default" className="rounded-full px-6 shadow-lg shadow-primary/20 font-bold">
            <Link href="/login">Portal Login</Link>
          </Button>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-20 px-6 max-w-7xl mx-auto text-center space-y-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent/10 border border-accent/20 text-accent-foreground font-semibold text-sm mb-4">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-accent"></span>
            </span>
            Official M-Zero Deployment: Madurai Municipal Corporation
          </div>
          <h1 className="text-5xl md:text-7xl font-black tracking-tight leading-[1.1] text-primary">
            Smart Waste Compliance <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Powered by AI</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto font-medium">
            Next-generation urban waste management system. Decentralized, QR-verified, and incentive-powered for a cleaner Madurai.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <Button asChild size="lg" className="h-14 px-8 rounded-2xl text-lg font-bold shadow-xl shadow-primary/20 gap-2">
              <Link href="/login">Access Hub <ArrowRight className="size-5" /></Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="h-14 px-8 rounded-2xl text-lg font-bold border-2 gap-2">
              <Link href="/dashboard/wards"><Zap className="size-5 text-accent fill-accent" /> View Ward League</Link>
            </Button>
          </div>
        </section>

        <section className="py-12 bg-primary/5">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-black text-primary">M-Zero Access Portals</h2>
              <p className="text-muted-foreground">Log in with your official ID to access role-specific dashboards</p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {portals.map((portal) => (
                <Card key={portal.title} className="rounded-3xl border-none shadow-sm hover:shadow-xl transition-all duration-300 group overflow-hidden bg-white">
                  <CardHeader>
                    <div className={`size-12 rounded-2xl flex items-center justify-center mb-4 ${portal.color}`}>
                      <portal.icon className="size-6" />
                    </div>
                    <CardTitle className="font-black">{portal.title}</CardTitle>
                    <CardDescription className="font-medium min-h-[60px]">
                      {portal.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button asChild className="w-full rounded-xl font-bold gap-2 group-hover:gap-3 transition-all">
                      <Link href={portal.href}>
                        {portal.label} <ArrowRight className="size-4" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 px-6">
          <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-8">
            <div className="p-8 bg-white rounded-3xl shadow-sm border border-primary/5 space-y-4">
              <div className="bg-primary/10 size-12 rounded-2xl flex items-center justify-center text-primary">
                <ShieldCheck className="size-6" />
              </div>
              <h3 className="text-xl font-bold">QR Verification</h3>
              <p className="text-muted-foreground">Every household is assigned a unique encrypted QR token for tamper-proof compliance logging.</p>
            </div>
            <div className="p-8 bg-white rounded-3xl shadow-sm border border-primary/5 space-y-4">
              <div className="bg-accent/10 size-12 rounded-2xl flex items-center justify-center text-accent-foreground">
                <Leaf className="size-6" />
              </div>
              <h3 className="text-xl font-bold">Decentralized MCCs</h3>
              <p className="text-muted-foreground">IoT-enabled Micro Composting Centres ensure wet waste is processed within 2km of its source.</p>
            </div>
            <div className="p-8 bg-white rounded-3xl shadow-sm border border-primary/5 space-y-4">
              <div className="bg-primary/10 size-12 rounded-2xl flex items-center justify-center text-primary">
                <Building2 className="size-6" />
              </div>
              <h3 className="text-xl font-bold">Tax Rebate Engine</h3>
              <p className="text-muted-foreground">Automated calculation of up to 5% Property Tax rebate based on verified daily segregation streaks.</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="py-12 px-6 border-t text-center text-muted-foreground text-sm font-medium bg-white">
        <p>© 2024 Madurai Municipal Corporation. M-Zero Framework v2.0</p>
      </footer>
    </div>
  )
}
