
"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table"
import { Search, Filter, MapPin, Trophy, TrendingUp, Zap, ChevronRight } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import Link from "next/link"

const wardData = [
  { id: "W10", name: "Anna Nagar", score: 92, compliance: 88, households: 1200, status: "High", rank: 1, trend: "up" },
  { id: "W13", name: "K.K. Nagar", score: 85, compliance: 82, households: 1500, status: "High", rank: 2, trend: "up" },
  { id: "W12", name: "Simmakkal", score: 78, compliance: 72, households: 1800, status: "Medium", rank: 3, trend: "down" },
  { id: "W15", name: "Goripalayam", score: 71, compliance: 68, households: 1950, status: "Medium", rank: 4, trend: "up" },
  { id: "W11", name: "Madurai Main", score: 65, compliance: 54, households: 2400, status: "Critical", rank: 5, trend: "down" },
  { id: "W14", name: "Sellur", score: 42, compliance: 38, households: 2100, status: "Critical", rank: 6, trend: "down" },
]

export default function WardsPage() {
  return (
    <div className="space-y-6 pb-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <Zap className="size-6 text-accent fill-accent" />
            <Badge variant="outline" className="bg-accent/10 text-accent-foreground border-accent/20 font-bold uppercase tracking-widest text-[10px]">
              Live Standings
            </Badge>
          </div>
          <h2 className="text-4xl font-black tracking-tighter text-primary">M-Zero Ward League</h2>
          <p className="text-muted-foreground font-medium">Public rankings based on segregation efficiency & local processing.</p>
        </div>
        
        <div className="flex gap-2 w-full md:w-auto">
          <div className="relative flex-1 md:w-[250px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search ward name..."
              className="pl-10 h-11 rounded-2xl border-none shadow-sm bg-white"
            />
          </div>
          <Button variant="outline" className="h-11 rounded-2xl bg-white border-none shadow-sm font-bold">
            <Filter className="mr-2 h-4 w-4" />
            Filters
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {wardData.slice(0, 3).map((ward, i) => (
          <Card key={ward.id} className={`rounded-3xl border-none shadow-md overflow-hidden relative ${i === 0 ? 'bg-primary text-primary-foreground' : 'bg-white'}`}>
            {i === 0 && (
              <div className="absolute top-0 right-0 p-4 opacity-20">
                <Trophy className="size-20" />
              </div>
            )}
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center mb-2">
                <span className={`text-[10px] font-black uppercase tracking-widest ${i === 0 ? 'text-white/70' : 'text-muted-foreground'}`}>Rank #{ward.rank}</span>
                {ward.trend === 'up' ? (
                  <TrendingUp className={`size-4 ${i === 0 ? 'text-accent' : 'text-primary'}`} />
                ) : (
                  <TrendingUp className="size-4 text-destructive rotate-180" />
                )}
              </div>
              <CardTitle className="text-2xl font-black">{ward.name}</CardTitle>
              <CardDescription className={i === 0 ? 'text-white/70' : 'text-muted-foreground'}>Ward {ward.id}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-end">
                  <span className="text-4xl font-black tracking-tighter">{ward.score}%</span>
                  <span className="text-[10px] font-bold uppercase opacity-70">Efficiency</span>
                </div>
                <Progress value={ward.score} className={`h-2 ${i === 0 ? 'bg-white/20' : 'bg-muted'}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="rounded-3xl border-none shadow-sm overflow-hidden bg-white">
        <CardHeader className="border-b bg-muted/20">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-black">City-Wide Leaderboard</CardTitle>
            <div className="flex gap-4">
              <div className="flex items-center gap-1.5">
                <div className="size-2 rounded-full bg-primary" />
                <span className="text-[10px] font-bold uppercase text-muted-foreground">High</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="size-2 rounded-full bg-accent" />
                <span className="text-[10px] font-bold uppercase text-muted-foreground">Medium</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="size-2 rounded-full bg-destructive" />
                <span className="text-[10px] font-bold uppercase text-muted-foreground">Critical</span>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/10">
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-[80px] font-black uppercase text-[10px] text-center">Rank</TableHead>
                <TableHead className="font-black uppercase text-[10px]">Ward Information</TableHead>
                <TableHead className="font-black uppercase text-[10px]">Households</TableHead>
                <TableHead className="font-black uppercase text-[10px]">Segregation Score</TableHead>
                <TableHead className="font-black uppercase text-[10px]">Risk Tier</TableHead>
                <TableHead className="text-right font-black uppercase text-[10px] pr-8">Performance</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {wardData.map((ward) => (
                <TableRow key={ward.id} className="group hover:bg-muted/30 transition-colors">
                  <TableCell className="text-center">
                    <span className="text-lg font-black text-primary">#{ward.rank}</span>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-bold text-sm">{ward.name}</span>
                      <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Ward {ward.id}</span>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium text-sm">{ward.households.toLocaleString()}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Progress value={ward.compliance} className="h-1.5 w-24" />
                      <span className="text-sm font-black text-primary">{ward.compliance}%</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant={
                        ward.status === "High" ? "default" : 
                        ward.status === "Medium" ? "secondary" : "destructive"
                      }
                      className="rounded-xl px-3 font-bold text-[10px] uppercase"
                    >
                      {ward.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right pr-8">
                    <Button variant="ghost" size="sm" className="rounded-xl font-bold gap-1 group-hover:text-primary transition-colors">
                      View Stats <ChevronRight className="size-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <div className="mt-8 grid md:grid-cols-2 gap-6">
        <Card className="rounded-3xl border-none shadow-sm overflow-hidden bg-gradient-to-br from-accent to-accent/80 text-accent-foreground p-6">
          <div className="flex gap-4">
            <div className="size-14 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur-md">
              <Trophy className="size-8" />
            </div>
            <div>
              <h4 className="text-xl font-black tracking-tight">Winning Ward Incentive</h4>
              <p className="text-sm font-medium opacity-80 mt-1">The top ward this month wins a ₹10 Lakh infrastructure development fund.</p>
            </div>
          </div>
        </Card>
        
        <Card className="rounded-3xl border-none shadow-sm overflow-hidden bg-white p-6 border-l-4 border-l-primary">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-lg font-black tracking-tight">Want to improve your ward's rank?</h4>
              <p className="text-xs font-medium text-muted-foreground mt-1">Consistency in segregation increases your ward multiplier.</p>
            </div>
            <Button asChild className="rounded-xl font-bold">
              <Link href="/login?role=citizen">Go to My Wallet</Link>
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}
