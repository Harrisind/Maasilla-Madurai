
"use client"

import { useState, useEffect, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Leaf, ShieldCheck, Truck, Home, Building2, LayoutDashboard } from "lucide-react"

function LoginContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("citizen")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const role = searchParams.get('role')
    if (role) setActiveTab(role)
  }, [searchParams])

  const handleLogin = (role: string) => {
    setLoading(true)
    setTimeout(() => {
      localStorage.setItem('userRole', role)
      // Standardize role IDs and redirection
      if (role === 'Citizen') router.push('/dashboard/wards?tab=wallet')
      else if (role === 'Field Worker') router.push('/field-agent')
      else if (role === 'Ward Officer') router.push('/dashboard/wards')
      else if (role === 'Admin') router.push('/dashboard')
      else router.push('/')
    }, 1000)
  }

  if (!mounted) {
    return (
      <div className="flex flex-col items-center justify-center p-12 bg-white rounded-3xl shadow-lg border border-primary/5">
        <div className="inline-flex p-3 rounded-2xl bg-primary text-white shadow-xl mb-4 animate-pulse">
          <Leaf className="size-8" />
        </div>
        <p className="text-muted-foreground font-medium">Initializing M-Zero Hub...</p>
      </div>
    )
  }

  return (
    <div className="w-full space-y-8 animate-in fade-in duration-700">
      <div className="text-center">
        <div className="inline-flex p-3 rounded-2xl bg-primary text-white shadow-xl mb-4">
          <Leaf className="size-8" />
        </div>
        <h1 className="text-3xl font-black tracking-tighter text-primary">M-Zero Hub</h1>
        <p className="text-muted-foreground mt-2">Civic FinTech & Waste Management</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 mb-4 h-12 gap-1 bg-muted/50 p-1 rounded-xl">
          <TabsTrigger value="citizen" className="text-[10px] font-bold rounded-lg px-0">
            <Home className="size-3 mr-1 hidden sm:block" /> Household
          </TabsTrigger>
          <TabsTrigger value="worker" className="text-[10px] font-bold rounded-lg px-0">
            <Truck className="size-3 mr-1 hidden sm:block" /> Worker
          </TabsTrigger>
          <TabsTrigger value="ward-officer" className="text-[10px] font-bold rounded-lg px-0">
            <Building2 className="size-3 mr-1 hidden sm:block" /> Ward
          </TabsTrigger>
          <TabsTrigger value="commissioner" className="text-[10px] font-bold rounded-lg px-0">
            <LayoutDashboard className="size-3 mr-1 hidden sm:block" /> HQ
          </TabsTrigger>
        </TabsList>

        <TabsContent value="citizen">
          <Card className="rounded-2xl border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Home className="size-5 text-primary" /> Citizen Wallet
              </CardTitle>
              <CardDescription>Enter your Property Tax ID to access Green Wallet</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="font-bold">Property Tax ID</Label>
                <Input placeholder="MDU-TX-10024" className="rounded-xl h-11" />
              </div>
              <Button className="w-full h-11 rounded-xl font-bold" onClick={() => handleLogin('Citizen')} disabled={loading}>
                {loading ? "Authenticating..." : "Access My Wallet"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="worker">
          <Card className="rounded-2xl border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="size-5 text-primary" /> Thooimai Kaavalargal
              </CardTitle>
              <CardDescription>Sanitary worker route scanner access</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="font-bold">Employee ID</Label>
                <Input placeholder="E100XXX" className="rounded-xl h-11" />
              </div>
              <Button className="w-full h-11 rounded-xl font-bold" variant="secondary" onClick={() => handleLogin('Field Worker')} disabled={loading}>
                {loading ? "Initializing..." : "Start Daily Route"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ward-officer">
          <Card className="rounded-2xl border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="size-5 text-primary" /> Ward Management
              </CardTitle>
              <CardDescription>Performance tracking for Ward Officers</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="font-bold">Officer ID / Ward ID</Label>
                <Input placeholder="WO-14-MDU" className="rounded-xl h-11" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">Access Token</Label>
                <Input type="password" placeholder="••••••••" className="rounded-xl h-11" />
              </div>
              <Button className="w-full h-11 rounded-xl font-bold" onClick={() => handleLogin('Ward Officer')} disabled={loading}>
                {loading ? "Loading Ward Data..." : "Open Ward Dashboard"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="commissioner">
          <Card className="rounded-2xl border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LayoutDashboard className="size-5 text-primary" /> HQ Command Center
              </CardTitle>
              <CardDescription>Strategic monitoring and financial oversight</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="font-bold">Admin Credentials</Label>
                <Input type="email" placeholder="commissioner@madurai.gov.in" className="rounded-xl h-11" />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">Security Key</Label>
                <Input type="password" placeholder="••••••••" className="rounded-xl h-11" />
              </div>
              <Button className="w-full h-11 rounded-xl font-bold" onClick={() => handleLogin('Admin')} disabled={loading}>
                {loading ? "Verifying Authority..." : "Access Command Hub"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <p className="text-center text-[10px] text-muted-foreground font-medium uppercase tracking-widest">
        Secure Biometric-Ready Encryption <ShieldCheck className="inline size-3 ml-1" />
      </p>
    </div>
  )
}

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="w-full max-w-md">
        <Suspense fallback={
          <div className="text-center">
            <div className="inline-flex p-3 rounded-2xl bg-primary text-white shadow-xl mb-4 animate-pulse">
              <Leaf className="size-8" />
            </div>
            <h1 className="text-3xl font-black tracking-tighter text-primary">M-Zero Hub</h1>
            <p className="text-muted-foreground mt-2">Loading secure portal...</p>
          </div>
        }>
          <LoginContent />
        </Suspense>
      </div>
    </div>
  )
}
