"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table"
import { Gift, Award, TrendingUp, Wallet } from "lucide-react"
import { Progress } from "@/components/ui/progress"

const incentiveData = [
  { id: "HH001", name: "Rajesh Kumar", score: 95, points: 450, eligibility: "High", amount: "₹250" },
  { id: "HH005", name: "Vignesh Raja", score: 91, points: 380, eligibility: "High", amount: "₹200" },
  { id: "HH004", name: "Anitha Devi", score: 88, points: 320, eligibility: "Medium", amount: "₹150" },
  { id: "HH012", name: "Meena Swaminathan", score: 42, points: 0, eligibility: "None", amount: "₹0" },
]

export default function IncentivesPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h2 className="text-3xl font-bold tracking-tight text-primary">Incentive Viewer</h2>
        <p className="text-muted-foreground">Rewarding sustainable habits based on compliance scores.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="bg-primary text-primary-foreground shadow-xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Wallet className="mr-2 size-4" />
              Total Payouts Distributed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">₹1,24,500</div>
            <p className="text-xs opacity-80 mt-2">Cycle: May 2024</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Award className="mr-2 size-4 text-accent" />
              Eligible Households
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">4,821</div>
            <div className="mt-2 flex items-center gap-2">
              <Progress value={65} className="h-1" />
              <span className="text-[10px] whitespace-nowrap">65% of Total</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <TrendingUp className="mr-2 size-4 text-primary" />
              Incentive Tiers
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between text-xs">
              <span>Platinum (&gt;90%)</span>
              <span className="font-bold">₹250</span>
            </div>
            <div className="flex justify-between text-xs">
              <span>Gold (80-90%)</span>
              <span className="font-bold">₹150</span>
            </div>
            <div className="flex justify-between text-xs">
              <span>Silver (70-80%)</span>
              <span className="font-bold">₹100</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Household Eligibility Table</CardTitle>
          <CardDescription>Current cycle rewards based on segregation performance.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>HH ID</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>Avg Score</TableHead>
                <TableHead>Reward Points</TableHead>
                <TableHead>Eligibility</TableHead>
                <TableHead className="text-right">Payout Amt</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {incentiveData.map((hh) => (
                <TableRow key={hh.id}>
                  <TableCell className="font-mono text-xs">{hh.id}</TableCell>
                  <TableCell className="font-medium">{hh.name}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span className="text-xs w-8">{hh.score}%</span>
                      <Progress value={hh.score} className="h-1 w-16" />
                    </div>
                  </TableCell>
                  <TableCell>{hh.points}</TableCell>
                  <TableCell>
                    <Badge variant={hh.eligibility === "High" ? "default" : hh.eligibility === "Medium" ? "secondary" : "outline"}>
                      {hh.eligibility}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-bold text-primary">
                    {hh.amount}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}