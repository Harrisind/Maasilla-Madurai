
"use client"

import { useState, useEffect, Suspense, useMemo } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table"
import { 
  Search, 
  MapPin, 
  Trophy, 
  TrendingUp, 
  Zap, 
  ChevronRight, 
  Wallet, 
  ShoppingBag,
  Truck,
  Clock,
  Send,
  Loader2,
  ShieldCheck,
  Users,
  Recycle,
  Sparkles,
  Bus,
  ArrowUpRight
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Label } from "@/components/ui/label"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useToast } from "@/hooks/use-toast"
import Image from "next/image"

function WardLeagueContent() {
  const { toast } = useToast()
  const searchParams = useSearchParams()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("league")
  const [withdrawing, setWithdrawing] = useState(false)
  const [upiId, setUpiId] = useState("murali@okaxis")
  const [withdrawAmount, setWithdrawAmount] = useState("500")
  const [withdrawDialogOpen, setWithdrawDialogOpen] = useState(false)
  const [selectedWardStats, setSelectedWardStats] = useState<any>(null)
  const [userName, setUserName] = useState("User")
  const [userRole, setUserRole] = useState<string | null>(null)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const role = localStorage.getItem('userRole')
    setUserRole(role)
    
    if (!role || (role !== 'Admin' && role !== 'Ward Officer' && role !== 'Citizen')) {
      router.push('/login')
      return
    }

    const tab = searchParams.get('tab')
    if (role === 'Ward Officer') {
      setActiveTab("league")
    } else if (tab === 'wallet' && role === 'Citizen') {
      setActiveTab("wallet")
    } else {
      setActiveTab("league")
    }
    
    const savedName = localStorage.getItem('userName')
    if (savedName) setUserName(savedName)
  }, [searchParams, router])

  const handleWithdraw = () => {
    if (!upiId.includes("@")) {
      toast({
        variant: "destructive",
        title: "Invalid UPI ID",
        description: "Please enter a valid UPI ID (e.g., name@bank)."
      })
      return
    }

    setWithdrawing(true)
    setTimeout(() => {
      setWithdrawing(false)
      setWithdrawDialogOpen(false)
      toast({
        title: "Transfer Initiated",
        description: `₹${(parseInt(withdrawAmount) / 4).toFixed(2)} is being sent to ${upiId}.`,
      })
    }, 2000)
  }

  const wardData = [
    { 
      id: "W10", 
      name: "Anna Nagar", 
      households: 1200, 
      compliance: 88, 
      status: "High", 
      rank: 1, 
      coordination: 94, 
      localProcessing: 91,
      tips: ["Maintain current streak", "Mentor neighboring wards"]
    },
    { 
      id: "W13", 
      name: "K.K. Nagar", 
      households: 1500, 
      compliance: 82, 
      status: "High", 
      rank: 2, 
      coordination: 88, 
      localProcessing: 85,
      tips: ["Increase plastic cleaning frequency", "Verify hazardous waste bins"]
    },
    { 
      id: "W12", 
      name: "Simmakkal", 
      households: 1800, 
      compliance: 72, 
      status: "Medium", 
      rank: 3, 
      coordination: 70, 
      localProcessing: 65,
      tips: [
        "Use Green Bins for food waste only",
        "Keep dry waste moisture-free",
        "Rinse milk packets before disposal"
      ]
    },
    { 
      id: "W11", 
      name: "Madurai Main", 
      households: 2400, 
      compliance: 54, 
      status: "Low", 
      rank: 5, 
      coordination: 45, 
      localProcessing: 40,
      tips: [
        "START TODAY: Get separate bins",
        "WET WASTE: Vegetable peels, leftover food",
        "HAZARDOUS: Diapers, napkins (wrap separately)"
      ]
    },
  ]

  if (!mounted) return <div className="p-10 text-center font-bold">Initializing M-Zero Hub...</div>

  return (
    <div className="space-y-6 pb-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <Zap className="size-6 text-accent fill-accent" />
            <Badge variant="outline" className="bg-accent/10 text-accent-foreground border-accent/20 font-bold uppercase tracking-widest text-[10px]">
              Live Standings
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <h2 className="text-4xl font-black tracking-tighter text-primary">Ward League</h2>
            <Badge variant="outline" className="h-fit bg-primary/5 text-primary border-primary/20 font-black text-xs px-3 rounded-full flex items-center gap-1.5">
              <Sparkles className="size-3" /> Welcome, {userName}
            </Badge>
          </div>
          <p className="text-muted-foreground font-medium">Public rankings & personal impact rewards.</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={(val) => {
        if (userRole === 'Ward Officer' && val === 'wallet') return;
        setActiveTab(val);
      }} className="w-full space-y-6">
        <TooltipProvider>
          <TabsList className={`grid w-full ${userRole === 'Ward Officer' ? 'grid-cols-1 max-w-[200px]' : 'grid-cols-2 max-w-[400px]'} h-12 bg-white/50 border p-1 rounded-2xl shadow-sm`}>
            <Tooltip delayDuration={300}>
              <TooltipTrigger asChild>
                <TabsTrigger value="league" className="rounded-xl font-black text-xs gap-2 data-[state=active]:bg-primary data-[state=active]:text-white">
                  <Trophy className="size-3.5" /> City League
                </TabsTrigger>
              </TooltipTrigger>
              <TooltipContent className="bg-primary text-white font-bold text-xs mb-2">
                City-wide standings and comparative ward performance.
              </TooltipContent>
            </Tooltip>

            {userRole !== 'Ward Officer' && (
              <Tooltip delayDuration={300}>
                <TooltipTrigger asChild>
                  <TabsTrigger value="wallet" className="rounded-xl font-black text-xs gap-2 data-[state=active]:bg-primary data-[state=active]:text-white">
                    <Wallet className="size-3.5" /> My Green Wallet
                  </TabsTrigger>
                </TooltipTrigger>
                <TooltipContent className="bg-primary text-white font-bold text-xs mb-2">
                  Manage your credits, streaks, and withdrawal options.
                </TooltipContent>
              </Tooltip>
            )}
          </TabsList>
        </TooltipProvider>

        <TabsContent value="league" className="space-y-6 animate-in fade-in duration-500">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 w-full md:max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search ward name..."
                className="pl-10 h-11 rounded-2xl border-none shadow-sm bg-white"
              />
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            {[
              { id: "W10", name: "Anna Nagar", score: 92, rank: 1, trend: 'up' },
              { id: "W13", name: "K.K. Nagar", score: 85, rank: 2, trend: 'up' },
              { id: "W12", name: "Simmakkal", score: 78, rank: 3, trend: 'down' }
            ].map((ward, i) => (
              <Card key={ward.id} className={`rounded-3xl border-none shadow-md overflow-hidden relative ${i === 0 ? 'bg-primary text-primary-foreground' : 'bg-white'}`}>
                {i === 0 && (
                  <div className="absolute top-0 right-0 p-4 opacity-20">
                    <Trophy className="size-20" />
                  </div>
                )}
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center mb-2">
                    <span className={`text-[10px] font-black uppercase tracking-widest ${i === 0 ? 'text-white/70' : 'text-muted-foreground'}`}>Rank #{ward.rank}</span>
                    <TrendingUp className={`size-4 ${ward.trend === 'up' ? (i === 0 ? 'text-accent' : 'text-primary') : 'text-destructive rotate-180'}`} />
                  </div>
                  <CardTitle className="text-2xl font-black">{ward.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-end">
                      <span className="text-4xl font-black tracking-tighter">{ward.score}%</span>
                      <span className="text-[10px] font-bold uppercase opacity-70">Efficiency</span>
                    </div>
                    <Progress value={ward.score} className={`h-2 ${i === 0 ? 'bg-white/20' : 'bg-muted'}`} />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="rounded-3xl border-none shadow-sm overflow-hidden bg-white">
            <CardHeader className="border-b bg-muted/20 px-6 py-4">
              <CardTitle className="text-xl font-black">City-Wide Leaderboard</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader className="bg-muted/10">
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="w-[80px] font-black uppercase text-[10px] text-center">Rank</TableHead>
                    <TableHead className="font-black uppercase text-[10px]">Ward Information</TableHead>
                    <TableHead className="font-black uppercase text-[10px]">Households</TableHead>
                    <TableHead className="font-black uppercase text-[10px]">Segregation</TableHead>
                    <TableHead className="font-black uppercase text-[10px]">Risk Tier</TableHead>
                    <TableHead className="text-right font-black uppercase text-[10px] pr-8">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {wardData.map((ward) => (
                    <TableRow key={ward.id} className="group hover:bg-muted/30 transition-colors">
                      <TableCell className="text-center"><span className="text-lg font-black text-primary">#{ward.rank}</span></TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-bold text-sm">{ward.name}</span>
                          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Ward {ward.id}</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium text-sm">{ward.households.toLocaleString()}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Progress value={ward.compliance} className="h-1.5 w-24" />
                          <span className="text-sm font-black text-primary">{ward.compliance}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={ward.status === "High" ? "default" : ward.status === "Medium" ? "secondary" : "destructive"} className="rounded-xl px-3 font-bold text-[10px] uppercase">{ward.status}</Badge>
                      </TableCell>
                      <TableCell className="text-right pr-8">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="rounded-xl font-bold gap-1 group-hover:text-primary transition-colors"
                              onClick={() => setSelectedWardStats(ward)}
                            >
                              View Stats <ChevronRight className="size-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-[500px] rounded-3xl p-0 overflow-hidden border-none shadow-2xl">
                            {selectedWardStats && (
                              <div className="flex flex-col">
                                <DialogHeader className="bg-primary p-6 text-primary-foreground space-y-0 text-left">
                                  <DialogTitle className="text-3xl font-black tracking-tight">{selectedWardStats.name}</DialogTitle>
                                  <DialogDescription className="text-primary-foreground/70 font-bold uppercase text-[10px] tracking-widest mt-1">
                                    Ward {selectedWardStats.id} • Rank #{selectedWardStats.rank}
                                  </DialogDescription>
                                </DialogHeader>
                                
                                <ScrollArea className="max-h-[70vh]">
                                  <div className="p-6 space-y-6">
                                    <div className="grid grid-cols-2 gap-4">
                                      <div className="p-4 rounded-2xl bg-primary/5 border border-primary/10">
                                        <div className="flex items-center gap-2 mb-2">
                                          <Users className="size-4 text-primary" />
                                          <span className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Coordination</span>
                                        </div>
                                        <p className="text-2xl font-black text-primary">{selectedWardStats.coordination}%</p>
                                      </div>
                                      <div className="p-4 rounded-2xl bg-accent/5 border border-accent/10">
                                        <div className="flex items-center gap-2 mb-2">
                                          <Recycle className="size-4 text-accent-foreground" />
                                          <span className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Local Processing</span>
                                        </div>
                                        <p className="text-2xl font-black text-accent-foreground">{selectedWardStats.localProcessing}%</p>
                                      </div>
                                    </div>

                                    <div className={`p-5 rounded-3xl border shadow-sm ${selectedWardStats.status !== 'High' ? 'bg-amber-50 border-amber-200' : 'bg-green-50 border-green-200'}`}>
                                      <h4 className="font-black text-sm text-foreground mb-4">
                                        {selectedWardStats.status !== 'High' ? 'Contribution Guide' : 'Sustain the Excellence'}
                                      </h4>
                                      <div className="space-y-3">
                                        {selectedWardStats.tips.map((tip: string, i: number) => (
                                          <div key={i} className="flex gap-3 text-sm font-medium">
                                            <div className="size-1.5 rounded-full mt-1.5 shrink-0 bg-primary" />
                                            <span>{tip}</span>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  </div>
                                </ScrollArea>
                                <div className="p-4 bg-muted/20 border-t">
                                  <Button className="w-full rounded-2xl font-black h-12" variant="outline" onClick={() => setSelectedWardStats(null)}>Close Insight</Button>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {userRole !== 'Ward Officer' && (
          <TabsContent value="wallet" className="space-y-6 animate-in slide-in-from-right-10 duration-500">
            <Card className="rounded-3xl border-none shadow-2xl overflow-hidden bg-white ring-4 ring-primary/5">
              <CardHeader className="bg-muted/20 border-b flex flex-row items-center justify-between py-4 px-6">
                <CardTitle className="text-xs font-black uppercase tracking-widest text-primary flex items-center gap-2">
                  <div className="size-2 bg-green-500 rounded-full animate-pulse" />
                  Live Collection Tracker
                </CardTitle>
                <Badge variant="outline" className="text-[9px] border-primary/20 text-primary font-bold">WARD 10 • ZONE B</Badge>
              </CardHeader>
              <CardContent className="p-0 flex flex-col md:flex-row h-[350px]">
                <div className="relative flex-1 h-full min-h-[250px] bg-muted/10">
                    <Image 
                      src="https://picsum.photos/seed/track-dash-live/800/600" 
                      alt="Tracking Map" 
                      fill 
                      className="object-cover opacity-90"
                      data-ai-hint="city map"
                    />
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 size-5 bg-primary border-4 border-white rounded-full shadow-2xl" />
                    <div className="absolute top-1/4 right-1/3 p-2 bg-accent rounded-xl border-2 border-white shadow-2xl animate-bounce">
                      <Truck className="size-5 text-accent-foreground" />
                    </div>
                </div>
                <div className="w-full md:w-80 bg-white p-8 flex flex-col justify-center gap-6 border-l shadow-inner">
                    <div>
                      <h4 className="text-2xl font-black tracking-tight text-primary">Murali is 450m away</h4>
                      <p className="text-sm text-muted-foreground font-medium flex items-center gap-1.5 mt-1">
                        <Clock className="size-3.5" /> Arrival in ~6 minutes
                      </p>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="default" className="w-full rounded-2xl font-black h-12 gap-2 shadow-lg shadow-primary/20">
                          <MapPin className="size-4" /> View Route Schedule
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-md rounded-3xl">
                        <DialogHeader>
                          <DialogTitle className="text-2xl font-black text-primary">Route Schedule</DialogTitle>
                          <DialogDescription className="font-bold">Ward 10 • Zone B Collection</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          {[
                            { block: "Block A - North Avenue", time: "07:30 AM", status: "Done" },
                            { block: "Block B - South Gate (Home)", time: "08:15 AM", status: "Live" },
                            { block: "Block C - Temple View", time: "09:00 AM", status: "Next" },
                          ].map((item, i) => (
                            <div key={i} className={`flex items-center justify-between p-4 rounded-2xl border ${item.status === 'Live' ? 'bg-primary/5 border-primary/20' : 'bg-muted/10'}`}>
                              <div>
                                <h5 className="font-bold text-sm">{item.block}</h5>
                                <p className="text-xs text-muted-foreground">{item.time}</p>
                              </div>
                              <Badge variant={item.status === 'Done' ? 'secondary' : item.status === 'Live' ? 'default' : 'outline'}>{item.status}</Badge>
                            </div>
                          ))}
                        </div>
                      </DialogContent>
                    </Dialog>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-primary text-primary-foreground shadow-2xl border-none relative overflow-hidden rounded-3xl p-8">
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <Wallet className="size-32" />
              </div>
              <div className="relative z-10 space-y-6">
                <div className="flex items-start justify-between">
                  <div>
                    <CardDescription className="text-primary-foreground/80 font-bold uppercase text-[10px]">Clean Credits Balance</CardDescription>
                    <h3 className="text-5xl font-black tracking-tighter mt-1">4,250 🌿</h3>
                  </div>
                  
                  <Dialog open={withdrawDialogOpen} onOpenChange={setWithdrawDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="secondary" size="lg" className="rounded-2xl font-black gap-2 h-14 px-6 shadow-xl">
                        <ArrowUpRight className="size-5" /> Withdraw to Bank
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px] rounded-3xl">
                      <DialogHeader>
                        <DialogTitle className="text-2xl font-black text-primary">UPI Transfer</DialogTitle>
                        <DialogDescription>Convert credits to cash instantly.</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-6 py-4">
                        <div className="space-y-2">
                          <Label htmlFor="upi" className="font-bold">UPI ID</Label>
                          <Input 
                            id="upi" 
                            placeholder="username@okaxis" 
                            className="rounded-xl h-12"
                            value={upiId}
                            onChange={(e) => setUpiId(e.target.value)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="amount" className="font-bold">Credits</Label>
                          <Input 
                            id="amount" 
                            type="number" 
                            className="rounded-xl h-12"
                            value={withdrawAmount}
                            onChange={(e) => setWithdrawAmount(e.target.value)}
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button className="w-full h-12 rounded-xl font-black" onClick={handleWithdraw} disabled={withdrawing}>
                          {withdrawing ? "Processing..." : "Transfer to Bank"}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </Card>

            <Card className="rounded-3xl border-none shadow-sm bg-white overflow-hidden p-6">
              <h4 className="font-black text-lg mb-4 flex items-center gap-2">
                <ShoppingBag className="size-5 text-primary" /> Redeem Rewards
              </h4>
              <div className="space-y-3">
                {[
                  { title: "TNPST Transport Pass", cost: "800 Credits", icon: <Bus className="size-5" /> },
                  { title: "Property Tax Rebate", cost: "3k Credits", icon: <ArrowUpRight className="size-5" /> },
                  { title: "Grocery Coupon", cost: "500 Credits", icon: <ShoppingBag className="size-5" /> },
                ].map((item, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-2xl bg-muted/20 border border-transparent hover:border-primary/10 transition-colors cursor-pointer">
                    <div className="flex items-center gap-3">
                      <div className="size-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                        {item.icon}
                      </div>
                      <span className="text-sm font-bold">{item.title}</span>
                    </div>
                    <Badge variant="secondary" className="font-black text-[10px]">{item.cost}</Badge>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  )
}

export default function WardsLeagueDashboard() {
  return (
    <Suspense fallback={<div className="p-10 text-center font-bold">Loading M-Zero Standings...</div>}>
      <WardLeagueContent />
    </Suspense>
  )
}
