
"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts"
import { 
  Leaf, 
  Users, 
  TrendingUp, 
  ArrowUpRight, 
  Wallet,
  Zap,
  Phone,
  Navigation,
  Sparkles
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import Image from "next/image"

const performanceData = [
  { ward: "W10", score: 85, rank: 1 },
  { ward: "W11", score: 62, rank: 14 },
  { ward: "W12", score: 78, rank: 5 },
  { ward: "W13", score: 91, rank: 2 },
  { ward: "W14", score: 44, rank: 20 },
]

const processingData = [
  { name: "MCC Processed", value: 65, color: "hsl(var(--primary))" },
  { name: "Landfill", value: 35, color: "hsl(var(--destructive))" },
]

const fieldForce = [
  { id: "E102", name: "R. Murali", phone: "+91 98400 12345", status: "Active", ward: "Ward 10", location: "South Gate" },
  { id: "E105", name: "S. Ganesh", phone: "+91 98400 54321", status: "Active", ward: "Ward 12", location: "Simmakkal" },
  { id: "E112", name: "K. Selvam", phone: "+91 98400 99887", status: "On Break", ward: "Ward 14", location: "Sellur" },
]

export default function AdminHubPage() {
  const [userName, setUserName] = useState("Commissioner")

  useEffect(() => {
    const savedName = localStorage.getItem('userName')
    if (savedName) setUserName(savedName)
  }, [])

  return (
    <div className="space-y-8 pb-10">
      <div className="flex justify-between items-end">
        <div className="flex flex-col gap-1">
          <Badge className="w-fit mb-2 bg-accent/20 text-accent-foreground border-accent/30 font-bold flex items-center gap-1.5">
            <Sparkles className="size-3" />
            Welcome back, {userName}
          </Badge>
          <h2 className="text-4xl font-black tracking-tight text-primary">Madurai Command Center</h2>
          <p className="text-muted-foreground font-medium">Strategic monitoring for City Commissioners.</p>
        </div>
        <div className="flex gap-4">
          <div className="text-right">
            <p className="text-[10px] uppercase font-bold text-muted-foreground">Today's Payouts</p>
            <p className="text-2xl font-black text-primary">₹45,280</p>
          </div>
          <div className="size-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary border border-primary/20">
            <Wallet className="size-6" />
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Source Segregation", value: "88.4%", icon: Leaf, change: "+12%", color: "text-primary" },
          { label: "Local Processing", value: "65.2%", icon: Zap, change: "+4.2%", color: "text-accent" },
          { label: "Clean Credits Issued", value: "1.2M", icon: Wallet, change: "+24k today", color: "text-primary" },
          { label: "Tax Rebate Liability", value: "₹1.4 Cr", icon: TrendingUp, change: "5% cap", color: "text-primary" },
        ].map((stat, i) => (
          <Card key={stat.label} className="hover:shadow-lg transition-all duration-300 rounded-3xl border-none bg-white shadow-sm overflow-hidden group">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs font-bold uppercase text-muted-foreground tracking-widest">{stat.label}</CardTitle>
              <stat.icon className={`h-5 w-5 ${stat.color} group-hover:scale-110 transition-transform`} />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black tracking-tighter">{stat.value}</div>
              <div className="flex items-center text-xs text-primary mt-2 font-bold bg-primary/5 w-fit px-2 py-0.5 rounded-full">
                <ArrowUpRight className="mr-1 h-3 w-3" />
                {stat.change}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2 rounded-3xl border-none shadow-sm overflow-hidden bg-white">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-xl font-black">Field Force Management</CardTitle>
              <CardDescription>Live tracking and contact details for Ward Officers.</CardDescription>
            </div>
            <Users className="size-5 text-primary opacity-20" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {fieldForce.map((worker) => (
                <div key={worker.id} className="flex items-center justify-between p-4 rounded-2xl bg-muted/20 border border-transparent hover:border-primary/10 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="size-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary font-black">
                      {worker.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <h4 className="font-bold text-sm">{worker.name}</h4>
                      <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider">{worker.ward} • {worker.location}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon" className="rounded-xl" asChild>
                      <a href={`tel:${worker.phone}`}>
                        <Phone className="size-4" />
                      </a>
                    </Button>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="default" size="icon" className="rounded-xl shadow-lg shadow-primary/20">
                          <Navigation className="size-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-md rounded-3xl p-0 overflow-hidden">
                        <DialogHeader className="p-6 bg-primary text-primary-foreground">
                          <DialogTitle className="text-2xl font-black">Live GPS: {worker.name}</DialogTitle>
                          <p className="text-xs opacity-80 uppercase font-bold tracking-widest">{worker.ward} Deployment</p>
                        </DialogHeader>
                        <div className="relative h-[300px] bg-muted">
                           <Image 
                            src="https://picsum.photos/seed/live-hq-track/800/600" 
                            alt="Live Tracking" 
                            fill 
                            className="object-cover"
                            data-ai-hint="city map"
                          />
                          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                             <div className="size-4 bg-primary border-2 border-white rounded-full shadow-2xl animate-pulse" />
                          </div>
                        </div>
                        <div className="p-4 bg-white flex justify-between items-center">
                           <div>
                              <p className="text-[10px] font-black uppercase text-muted-foreground">Current Status</p>
                              <p className="text-sm font-bold">{worker.status} - Scanning Block B</p>
                           </div>
                           <Badge variant="outline" className="font-black text-primary">Last Scan: 2m ago</Badge>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-3xl border-none shadow-sm overflow-hidden bg-white">
          <CardHeader>
            <CardTitle className="text-xl font-black">M-Zero Ward League</CardTitle>
            <CardDescription>Efficiency standings by Ward.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis dataKey="ward" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700 }} />
                  <YAxis axisLine={false} tickLine={false} hide />
                  <RechartsTooltip cursor={{ fill: '#f2f5ee' }} contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 25px rgba(0,0,0,0.05)' }} />
                  <Bar dataKey="score" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} barSize={30} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="rounded-3xl border-none shadow-sm overflow-hidden bg-white">
          <CardHeader>
            <CardTitle className="text-xl font-black">Decentralized Processing</CardTitle>
            <CardDescription>MCC vs Landfill Metrics</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={processingData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={8} dataKey="value" stroke="none">
                    {processingData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <RechartsTooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center gap-6 w-full mt-4">
              {processingData.map((item) => (
                <div key={item.name} className="flex flex-col items-center">
                  <div className="size-3 rounded-full mb-1" style={{ backgroundColor: item.color }} />
                  <span className="text-[10px] font-bold uppercase text-muted-foreground">{item.name}</span>
                  <span className="text-sm font-black">{item.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-3xl border-none shadow-sm overflow-hidden bg-gradient-to-br from-primary to-primary/90 text-primary-foreground">
          <CardHeader>
            <CardTitle className="text-xl font-black">Swachh AI Forecast</CardTitle>
            <CardDescription className="text-primary-foreground/70">Predictive analysis for Madurai 2027.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-white/10 rounded-2xl backdrop-blur-md">
              <p className="text-sm font-medium leading-relaxed italic">
                "Field deployment optimization in Ward 10 suggests a 15% improvement in daily scan rates. AI recommends rotating staff for Zone C by Q3."
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-white/5 rounded-xl text-center">
                <p className="text-[10px] uppercase opacity-70">Staff Utilization</p>
                <p className="text-xl font-black">94%</p>
              </div>
              <div className="p-3 bg-white/5 rounded-xl text-center">
                <p className="text-[10px] uppercase opacity-70">Coverage</p>
                <p className="text-xl font-black">100%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
