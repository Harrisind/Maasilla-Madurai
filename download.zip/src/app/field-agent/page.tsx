
"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { 
  QrCode, 
  Camera, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  MapPin, 
  Truck, 
  Zap, 
  Navigation,
  ListTodo,
  ChevronRight,
  CircleDot,
  Sparkles,
  UserCircle,
  Check,
  LogOut
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import Image from "next/image"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

const routeStops = [
  { id: "HH-1024", address: "10, South Gate", status: "completed", type: "Green" },
  { id: "HH-1035", address: "14, South Gate", status: "completed", type: "Green" },
  { id: "HH-1042", address: "12, South Gate", status: "next", type: "Pending" },
  { id: "HH-1056", address: "22, West Street", status: "pending", type: "Pending" },
  { id: "HH-1088", address: "5, West Street", status: "pending", type: "Pending" },
]

export default function FieldAgentDashboard() {
  const { toast } = useToast()
  const router = useRouter()
  const [scanning, setScanning] = useState(false)
  const [activeHH, setActiveHH] = useState<any>(null)
  const [activeTab, setActiveTab] = useState("scan")
  const [userName, setUserName] = useState("Field Worker")
  const [tempName, setTempName] = useState("")
  const [isProfileOpen, setIsProfileOpen] = useState(false)

  useEffect(() => {
    const role = localStorage.getItem('userRole')
    if (!role || role !== 'Field Worker') {
      router.push('/login')
      return
    }

    const savedName = localStorage.getItem('userName')
    if (savedName) {
      setUserName(savedName)
      setTempName(savedName)
    }
  }, [router])

  const saveProfile = () => {
    localStorage.setItem('userName', tempName)
    setUserName(tempName)
    setIsProfileOpen(false)
    toast({
      title: "Profile Updated",
      description: "Your name has been updated across the M-Zero network."
    })
  }

  const handleScan = () => {
    setScanning(true)
    setTimeout(() => {
      setScanning(false)
      setActiveHH({
        id: "HH-1042",
        address: "12, South Gate, Ward 10",
        streak: 15,
        owner: "R. Murali"
      })
      setActiveTab("scan")
    }, 1500)
  }

  const logStatus = (status: "Green" | "Red" | "Yellow") => {
    toast({
      title: "Log Recorded",
      description: `Status: ${status} for ${activeHH.id}. Reward engine updated.`
    })
    setActiveHH(null)
  }

  return (
    <div className="max-w-md mx-auto space-y-6 min-h-screen flex flex-col p-4 bg-muted/20 pb-20">
      {/* Header */}
      <div className="flex justify-between items-center bg-white p-4 rounded-3xl shadow-sm border">
        <div className="flex items-center gap-3">
          <div className="bg-primary p-2 rounded-xl text-white shadow-md">
            <Truck className="size-5" />
          </div>
          <div>
            <Badge variant="outline" className="h-4 px-1.5 rounded-lg border-primary/20 bg-primary/5 font-black text-[8px] mb-0.5 flex items-center gap-1">
              <Sparkles className="size-2" /> Welcome, {userName}
            </Badge>
            <h4 className="font-black text-sm text-primary">Ward 10 - Zone B</h4>
          </div>
        </div>
        <div className="flex gap-2">
          <Dialog open={isProfileOpen} onOpenChange={setIsProfileOpen}>
            <TooltipProvider>
              <Tooltip delayDuration={300}>
                <TooltipTrigger asChild>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="icon" className="rounded-xl text-primary hover:bg-primary/5">
                      <UserCircle className="size-5" />
                    </Button>
                  </DialogTrigger>
                </TooltipTrigger>
                <TooltipContent className="bg-primary text-white font-bold text-xs mb-2">
                  Edit your field agent profile and name.
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <DialogContent className="rounded-3xl sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="text-2xl font-black">Agent Profile</DialogTitle>
                <DialogDescription className="font-medium">Update your name as it appears in city logs.</DialogDescription>
              </DialogHeader>
              <div className="py-6 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="agentName" className="font-bold">Full Name</Label>
                  <Input 
                    id="agentName" 
                    value={tempName} 
                    onChange={(e) => setTempName(e.target.value)} 
                    className="rounded-xl h-11"
                  />
                </div>
              </div>
              <DialogFooter className="flex-col gap-2">
                <Button className="w-full rounded-xl font-bold h-11" onClick={saveProfile}>
                  <Check className="size-4 mr-2" /> Save Changes
                </Button>
                <Button variant="ghost" className="w-full text-destructive font-bold h-11" onClick={() => {
                  localStorage.clear();
                  router.push('/login');
                }}>
                  <LogOut className="size-4 mr-2" /> Logout
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <TooltipProvider>
            <Tooltip delayDuration={300}>
              <TooltipTrigger asChild>
                <Button asChild variant="ghost" size="icon" className="rounded-xl text-primary hover:bg-primary/5">
                  <Link href="/dashboard/wards">
                    <Zap className="size-5" />
                  </Link>
                </Button>
              </TooltipTrigger>
              <TooltipContent className="bg-primary text-white font-bold text-xs">
                City standings and public ward rankings.
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <Badge variant="outline" className="h-10 px-3 rounded-xl border-primary/20 bg-primary/5 font-black">
            <MapPin className="size-3 mr-1 text-primary" /> 14/120
          </Badge>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      {!activeHH && (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full flex-1 flex flex-col gap-4">
          <TooltipProvider>
            <TabsList className="grid w-full grid-cols-2 bg-white h-12 rounded-2xl p-1 border shadow-sm">
              <Tooltip delayDuration={300}>
                <TooltipTrigger asChild>
                  <TabsTrigger value="scan" className="rounded-xl font-black text-xs gap-2 data-[state=active]:bg-primary data-[state=active]:text-white transition-all">
                    <QrCode className="size-4" /> Scanner
                  </TabsTrigger>
                </TooltipTrigger>
                <TooltipContent className="bg-primary text-white font-bold text-xs mb-2">
                  Verify household waste segregation via QR scanning.
                </TooltipContent>
              </Tooltip>

              <Tooltip delayDuration={300}>
                <TooltipTrigger asChild>
                  <TabsTrigger value="map" className="rounded-xl font-black text-xs gap-2 data-[state=active]:bg-primary data-[state=active]:text-white transition-all">
                    <Navigation className="size-4" /> Route Map
                  </TabsTrigger>
                </TooltipTrigger>
                <TooltipContent className="bg-primary text-white font-bold text-xs mb-2">
                  Visualize assigned collection path and pending stops.
                </TooltipContent>
              </Tooltip>
            </TabsList>
          </TooltipProvider>

          <TabsContent value="scan" className="flex-1 flex flex-col animate-in fade-in zoom-in-95 duration-300">
            <Card className="flex-1 border-dashed border-2 flex flex-col items-center justify-center text-center p-8 rounded-3xl bg-white/50 backdrop-blur-sm">
              <div className={`p-10 rounded-full mb-6 transition-all duration-500 shadow-inner ${scanning ? 'bg-primary/20 scale-110' : 'bg-primary/10'}`}>
                <QrCode className={`size-16 text-primary ${scanning ? 'animate-pulse' : ''}`} />
              </div>
              <h3 className="text-xl font-black mb-2 text-primary">Scan Household QR</h3>
              <p className="text-sm text-muted-foreground mb-8 font-medium">Align the household QR sticker within the frame to verify segregation.</p>
              <Button onClick={handleScan} size="lg" className="w-full h-16 rounded-2xl text-lg font-black shadow-xl shadow-primary/20" disabled={scanning}>
                <Camera className="mr-2 size-6" />
                {scanning ? "Initializing..." : "Open Scanner"}
              </Button>
            </Card>
          </TabsContent>

          <TabsContent value="map" className="flex-1 space-y-4 animate-in slide-in-from-right-10 duration-500">
            <Card className="relative h-[300px] rounded-3xl overflow-hidden border-none shadow-lg group">
              <Image 
                src="https://picsum.photos/seed/madurai-map/600/800" 
                alt="Route Map" 
                fill 
                className="object-cover opacity-90 group-hover:scale-105 transition-transform duration-1000"
                data-ai-hint="city map"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
              
              {/* Simulated Map Markers */}
              <div className="absolute top-1/4 left-1/3 size-6 rounded-full bg-green-500 border-4 border-white shadow-lg animate-bounce" />
              <div className="absolute top-1/2 left-2/3 size-6 rounded-full bg-primary border-4 border-white shadow-xl ring-4 ring-primary/20" />
              <div className="absolute bottom-1/4 right-1/4 size-4 rounded-full bg-muted border-2 border-white opacity-50" />
              
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <div className="flex items-center gap-2">
                  <div className="size-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Live GPS Active</span>
                </div>
                <h4 className="font-black text-lg">Next Stop: 12, South Gate</h4>
              </div>
            </Card>

            <div className="space-y-3">
              <h3 className="text-xs font-black uppercase text-muted-foreground tracking-widest flex items-center gap-2 px-2">
                <ListTodo className="size-3" /> Route Checklist
              </h3>
              {routeStops.map((stop, i) => (
                <Card key={i} className={`rounded-2xl border-none shadow-sm transition-all ${stop.status === 'next' ? 'ring-2 ring-primary ring-offset-2' : 'bg-white opacity-80'}`}>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`size-10 rounded-xl flex items-center justify-center font-bold ${
                        stop.status === 'completed' ? 'bg-green-100 text-green-600' : 
                        stop.status === 'next' ? 'bg-primary text-white shadow-lg' : 'bg-muted text-muted-foreground'
                      }`}>
                        {stop.status === 'completed' ? <CheckCircle2 className="size-5" /> : <CircleDot className="size-5" />}
                      </div>
                      <div>
                        <h4 className={`text-sm font-bold ${stop.status === 'next' ? 'text-primary' : ''}`}>{stop.address}</h4>
                        <p className="text-[10px] font-bold text-muted-foreground uppercase">{stop.id}</p>
                      </div>
                    </div>
                    {stop.status === 'next' && (
                      <Button size="sm" variant="ghost" className="rounded-lg font-black text-primary gap-1" onClick={handleScan}>
                        Collect <ChevronRight className="size-4" />
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      )}

      {/* Active Household Log UI */}
      {activeHH && (
        <Card className="flex-1 animate-in slide-in-from-bottom-10 duration-500 rounded-3xl shadow-2xl border-none overflow-hidden flex flex-col">
          <CardHeader className="bg-primary text-primary-foreground p-6 pb-12">
            <div className="flex justify-between items-start mb-4">
              <Badge variant="secondary" className="bg-white/20 text-white border-none font-black text-[10px]">VERIFIED SCAN</Badge>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10" onClick={() => setActiveHH(null)}>
                <XCircle className="size-6" />
              </Button>
            </div>
            <CardTitle className="text-3xl font-black tracking-tighter">{activeHH.id}</CardTitle>
            <CardDescription className="text-primary-foreground/90 font-bold flex items-center gap-1">
              <MapPin className="size-3" /> {activeHH.address}
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6 pt-0 flex-1 flex flex-col -mt-6">
            <div className="bg-white p-5 rounded-3xl shadow-xl border space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">Resident Owner</p>
                  <p className="text-md font-bold text-primary">{activeHH.owner}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] uppercase font-black text-muted-foreground tracking-widest">Streak</p>
                  <p className="text-lg font-black flex items-center justify-end text-orange-500">
                    <Zap className="size-4 mr-1 fill-orange-500" /> {activeHH.streak}
                  </p>
                </div>
              </div>
              <div className="h-px bg-muted w-full" />
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-muted-foreground uppercase tracking-widest">Risk Tier</span>
                <Badge className="bg-green-100 text-green-700 hover:bg-green-100 font-black px-4 rounded-full">Elite Segregator</Badge>
              </div>
            </div>

            <div className="space-y-3 flex-1">
              <h4 className="font-black text-center text-xs uppercase tracking-widest text-muted-foreground flex items-center justify-center gap-2">
                <span className="h-px w-8 bg-muted" /> Mark Segregation Status <span className="h-px w-8 bg-muted" />
              </h4>
              <div className="grid gap-3">
                <Button 
                  variant="outline" 
                  className="h-20 border-2 border-green-500 hover:bg-green-50 justify-between px-6 rounded-2xl group transition-all" 
                  onClick={() => logStatus("Green")}
                >
                  <div className="flex items-center gap-4">
                    <CheckCircle2 className="size-8 text-green-500" />
                    <div className="text-left">
                      <span className="block font-black text-green-700 text-lg tracking-tight">GREEN</span>
                      <span className="text-[10px] text-muted-foreground font-black uppercase">Segregated (+10 Credits)</span>
                    </div>
                  </div>
                  <ChevronRight className="size-5 text-green-200 group-hover:translate-x-1 transition-transform" />
                </Button>

                <Button 
                  variant="outline" 
                  className="h-20 border-2 border-yellow-500 hover:bg-yellow-50 justify-between px-6 rounded-2xl group transition-all" 
                  onClick={() => logStatus("Yellow")}
                >
                  <div className="flex items-center gap-4">
                    <AlertCircle className="size-8 text-yellow-500" />
                    <div className="text-left">
                      <span className="block font-black text-yellow-700 text-lg tracking-tight">YELLOW</span>
                      <span className="text-[10px] text-muted-foreground font-black uppercase">Partially Mixed (0 Credits)</span>
                    </div>
                  </div>
                  <ChevronRight className="size-5 text-yellow-200 group-hover:translate-x-1 transition-transform" />
                </Button>

                <Button 
                  variant="outline" 
                  className="h-20 border-2 border-destructive hover:bg-destructive/5 justify-between px-6 rounded-2xl group transition-all" 
                  onClick={() => logStatus("Red")}
                >
                  <div className="flex items-center gap-4">
                    <XCircle className="size-8 text-destructive" />
                    <div className="text-left">
                      <span className="block font-black text-destructive text-lg tracking-tight">RED</span>
                      <span className="text-[10px] text-muted-foreground font-black uppercase">Mixed (Streak Reset)</span>
                    </div>
                  </div>
                  <ChevronRight className="size-5 text-destructive/20 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Persistent Bottom Stats (Mobile Optimized) */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-md border-t p-3 flex justify-around items-center z-50">
        <div className="text-center">
          <p className="text-[9px] font-black uppercase text-muted-foreground">Earnings</p>
          <p className="text-sm font-black text-primary">₹1,240</p>
        </div>
        <div className="w-px h-8 bg-muted" />
        <div className="text-center">
          <p className="text-[9px] font-black uppercase text-muted-foreground">Accuracy</p>
          <p className="text-sm font-black text-primary">98.4%</p>
        </div>
        <div className="w-px h-8 bg-muted" />
        <div className="text-center">
          <p className="text-[9px] font-black uppercase text-muted-foreground">Stops Left</p>
          <p className="text-sm font-black text-primary">106</p>
        </div>
      </div>
    </div>
  )
}
