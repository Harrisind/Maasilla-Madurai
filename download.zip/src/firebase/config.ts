export const firebaseConfig = {
  "projectId": "studio-269592979-94c9b",
  "appId": "1:1005630296185:web:0a97474134b7ac9cc184a8",
  "apiKey": "AIzaSyAdfOf5Dth55vELM9SoA9hdz2avBVg3drs",
  "authDomain": "studio-269592979-94c9b.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "1005630296185"
};
