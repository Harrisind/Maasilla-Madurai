'use server';
/**
 * @fileOverview A Genkit flow for generating an AI-powered summary of waste collection log issues,
 * common rejection reasons, and emerging patterns within a specific ward.
 *
 * - aiCollectionLogSummary - A function that handles the AI summary generation.
 * - CollectionLogSummaryInput - The input type for the aiCollectionLogSummary function.
 * - CollectionLogSummaryOutput - The return type for the aiCollectionLogSummary function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const CollectionLogSchema = z.object({
  logId: z.string().describe('Unique identifier for the collection log entry.'),
  householdId: z.string().describe('ID of the household associated with this log.'),
  status: z.enum(['accepted', 'rejected']).describe('Status of the waste collection (accepted or rejected).'),
  rejectionReason: z.string().optional().describe('Reason for rejection, if the status is "rejected".'),
  timestamp: z.string().datetime().describe('Timestamp when the collection log was recorded.'),
  wasteType: z.string().optional().describe('Type of waste collected (e.g., "wet", "dry", "mixed").'),
  notes: z.string().optional().describe('Additional notes or observations from the field worker.'),
});

const CollectionLogSummaryInputSchema = z.object({
  wardId: z.string().describe('The ID of the ward for which to generate the summary.'),
  collectionLogs: z.array(CollectionLogSchema).describe('A list of recent waste collection log entries for the ward.'),
});
export type CollectionLogSummaryInput = z.infer<typeof CollectionLogSummaryInputSchema>;

const CommonRejectionReasonSchema = z.object({
  reason: z.string().describe('The common reason for rejection.'),
  count: z.number().int().describe('The number of times this rejection reason occurred.'),
});

const CollectionLogSummaryOutputSchema = z.object({
  summary: z.string().describe('A comprehensive AI-generated summary of recent waste collection log issues and their overall impact.'),
  commonRejectionReasons: z.array(CommonRejectionReasonSchema).describe('A list of the most common reasons for waste collection rejections, along with their frequencies.'),
  emergingPatterns: z.string().describe('A description of any emerging patterns or trends observed in the waste collection logs, such as specific areas with high rejection rates, recurring issues, or time-based trends.'),
});
export type CollectionLogSummaryOutput = z.infer<typeof CollectionLogSummaryOutputSchema>;

export async function aiCollectionLogSummary(
  input: CollectionLogSummaryInput
): Promise<CollectionLogSummaryOutput> {
  return aiCollectionLogSummaryFlow(input);
}

const aiCollectionLogSummaryPrompt = ai.definePrompt({
  name: 'aiCollectionLogSummaryPrompt',
  input: { schema: CollectionLogSummaryInputSchema },
  output: { schema: CollectionLogSummaryOutputSchema },
  prompt: `You are an AI assistant specialized in analyzing waste management data for urban wards. Your task is to provide a concise summary of recent waste collection log issues, identify common rejection reasons, and highlight any emerging patterns for Ward ID: {{{wardId}}}.

Analyze the following raw waste collection log data:

{{#if collectionLogs}}
Waste Collection Logs:
{{#each collectionLogs}}
- Log ID: {{{logId}}}, Household ID: {{{householdId}}}, Status: {{{status}}}, Rejection Reason: {{{rejectionReason}}}{{#if rejectionReason}}, Notes: {{{notes}}}{{/if}}, Timestamp: {{{timestamp}}}, Waste Type: {{{wasteType}}}
{{/each}}
{{else}}
No collection logs provided for analysis.
{{/if}}

Based on the provided data, generate a summary that includes:
1. A comprehensive overview of the recent waste collection log issues and their overall impact.
2. The most common reasons for waste collection rejections, along with their frequencies.
3. Any emerging patterns or trends observed, such as specific areas (households) with consistently high rejection rates, recurring issues, or time-based trends.

Ensure the output strictly adheres to the JSON schema provided, including the 'summary', 'commonRejectionReasons' (as an array of objects with 'reason' and 'count'), and 'emergingPatterns' fields. If no logs are provided, indicate that in the summary.
`,
});

const aiCollectionLogSummaryFlow = ai.defineFlow(
  {
    name: 'aiCollectionLogSummaryFlow',
    inputSchema: CollectionLogSummaryInputSchema,
    outputSchema: CollectionLogSummaryOutputSchema,
  },
  async (input) => {
    const { output } = await aiCollectionLogSummaryPrompt(input);
    return output!;
  }
);
