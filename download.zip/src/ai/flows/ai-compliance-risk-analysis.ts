'use server';
/**
 * @fileOverview An AI agent for assessing compliance risk and providing recommendations for households or wards.
 *
 * - aiComplianceRiskAnalysis - A function that handles the AI-powered compliance risk analysis process.
 * - AiComplianceRiskAnalysisInput - The input type for the aiComplianceRiskAnalysis function.
 * - AiComplianceRiskAnalysisOutput - The return type for the aiComplianceRiskAnalysis function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiComplianceHistoryEntrySchema = z.object({
  date: z.string().describe('Date of the compliance event in YYYY-MM-DD format.'),
  status: z.enum(['compliant', 'non-compliant', 'partially-compliant']).describe('Compliance status for the event.'),
  reason: z.string().optional().describe('Reason for non-compliance, if applicable.'),
});

const AiWasteDetailsSchema = z.object({
  averageSegregationScore: z.number().min(0).max(100).describe('Average waste segregation score (0-100).'),
  commonSegregationErrors: z.array(z.string()).describe('List of common waste segregation errors.'),
});

const AiComplianceRiskAnalysisInputSchema = z.object({
  entityId: z.string().describe('ID of the household or ward being analyzed.'),
  entityType: z.enum(['household', 'ward']).describe('Type of entity being analyzed.'),
  complianceHistory: z.array(AiComplianceHistoryEntrySchema).describe('Historical compliance data.'),
  wasteDetails: AiWasteDetailsSchema.describe('Detailed information about waste segregation.'),
  rejectionReasons: z.array(z.string()).describe('Common reasons for waste rejection from collection logs.'),
});
export type AiComplianceRiskAnalysisInput = z.infer<typeof AiComplianceRiskAnalysisInputSchema>;

const AiComplianceRiskAnalysisOutputSchema = z.object({
  riskScore: z.number().min(0).max(100).describe('A numerical score indicating the compliance risk (0-100, higher is riskier).'),
  riskLevel: z.enum(['low', 'medium', 'high', 'critical']).describe('Categorical risk level for compliance.'),
  insights: z.string().describe('A comprehensive textual summary of the compliance situation and contributing factors.'),
  recommendations: z.array(z.string()).describe('A list of actionable recommendations to improve compliance.'),
  predictedFutureCompliance: z.string().describe('A prediction about the entity\'s future compliance status if current trends continue.'),
});
export type AiComplianceRiskAnalysisOutput = z.infer<typeof AiComplianceRiskAnalysisOutputSchema>;

export async function aiComplianceRiskAnalysis(input: AiComplianceRiskAnalysisInput): Promise<AiComplianceRiskAnalysisOutput> {
  return aiComplianceRiskAnalysisFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiComplianceRiskAnalysisPrompt',
  input: { schema: AiComplianceRiskAnalysisInputSchema },
  output: { schema: AiComplianceRiskAnalysisOutputSchema },
  prompt: `You are an AI expert in urban waste management and compliance, providing insights and recommendations for improving waste segregation.
Your task is to analyze the provided data for a specific {{{entityType}}} and generate a compliance risk assessment, insights, and actionable recommendations.

Here is the data for the {{{entityType}}} with ID: {{{entityId}}}

Compliance History:
{{#if complianceHistory}}
  {{#each complianceHistory}}
    - Date: {{{date}}}, Status: {{{status}}}{{#if reason}}, Reason: {{{reason}}}{{/if}}
  {{/each}}
{{else}}
  No compliance history available.
{{/if}}

Waste Segregation Details:
- Average Segregation Score: {{{wasteDetails.averageSegregationScore}}}
- Common Segregation Errors:
  {{#if wasteDetails.commonSegregationErrors}}
    {{#each wasteDetails.commonSegregationErrors}}
      - {{{this}}}
    {{/each}}
  {{else}}
    None reported.
  {{/if}}

Common Waste Rejection Reasons (from collection logs):
{{#if rejectionReasons}}
  {{#each rejectionReasons}}
    - {{{this}}}
  {{/each}}
{{else}}
  No rejection reasons reported.
{{/if}}

Based on this information, provide:
1.  A 'riskScore' between 0 and 100, where a higher score indicates higher risk of non-compliance.
2.  A 'riskLevel' (low, medium, high, critical).
3.  'insights': A detailed summary of the current compliance situation, identifying patterns, strengths, and weaknesses.
4.  'recommendations': A list of specific, actionable steps to improve waste segregation and compliance for this {{{entityType}}}.
5.  'predictedFutureCompliance': A prediction of future compliance status if current trends continue.

Ensure your output strictly adheres to the JSON schema provided.`,
});

const aiComplianceRiskAnalysisFlow = ai.defineFlow(
  {
    name: 'aiComplianceRiskAnalysisFlow',
    inputSchema: AiComplianceRiskAnalysisInputSchema,
    outputSchema: AiComplianceRiskAnalysisOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    if (!output) {
      throw new Error('AI did not return a valid output for compliance risk analysis.');
    }
    return output;
  }
);
