import { config } from 'dotenv';
config();

import '@/ai/flows/ai-collection-log-summary.ts';
import '@/ai/flows/ai-compliance-risk-analysis.ts';